"""TP7 — Concepts avances : branching, TaskGroups, dynamic task mapping, trigger rules.

Le piege a connaitre : apres un branching, la tache de jonction doit utiliser
trigger_rule="none_failed_min_one_success", sinon elle est SKIPPEE en cascade.
"""
from __future__ import annotations

from datetime import datetime

from airflow.sdk import dag, task, task_group
from airflow.providers.standard.operators.empty import EmptyOperator


@dag(
    dag_id="snowystore_advanced",
    start_date=datetime(2026, 7, 20),
    schedule="@daily",
    catchup=False,
    tags=["snowystore", "tp7"],
)
def snowystore_advanced():

    @task.branch
    def choose_load_mode(**context) -> str:
        """Lundi : chargement complet. Autres jours : incremental."""
        weekday = context["data_interval_start"].weekday()   # 0 = lundi
        return "full_load" if weekday == 0 else "incremental_load"

    @task
    def full_load():
        print("Chargement COMPLET")

    @task
    def incremental_load():
        print("Chargement INCREMENTAL")

    @task
    def get_categories() -> list[str]:
        """La liste est connue a l'execution : le mapping s'y adapte."""
        return ["ski", "snowboard", "textile", "accessoires", "chaussures"]

    @task_group(group_id="transformations")
    def transformations(categories):
        @task
        def transform_category(category: str, run_env: str) -> str:
            print(f"[{run_env}] transformation de la categorie {category}")
            return category

        # .partial() fige les arguments constants, .expand() itere sur ceux qui varient.
        return transform_category.partial(run_env="formation").expand(category=categories)

    # PIEGE : sans cette trigger_rule, join serait skippee (une branche est toujours "skipped").
    join = EmptyOperator(task_id="join", trigger_rule="none_failed_min_one_success")

    @task
    def notify():
        print("Pipeline avance termine")

    branch = choose_load_mode()
    full = full_load()
    incr = incremental_load()
    branch >> [full, incr] >> join

    cats = get_categories()
    join >> cats
    transformations(cats) >> notify()


snowystore_advanced()

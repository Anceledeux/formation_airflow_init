#!/usr/bin/env bash
# TP SECURITE (nouveau) — RBAC en pratique, 10 minutes, sans infrastructure supplementaire.
#
# Objectif : constater concretement le principe du MOINDRE PRIVILEGE.
#
# Mission 1 : creer un utilisateur avec le role Viewer
# Mission 2 : se deconnecter, se reconnecter en tant que 'analyste'
# Mission 3 : constater ce qui est possible (voir les DAGs, lire les logs)
#             et ce qui ne l'est PAS (declencher, mettre en pause, editer une Connection)
# Mission 4 : reflechir — quel role donneriez-vous a un analyste metier ? a un data engineer ?
#
# A executer DANS le conteneur :  astro dev bash   puis   bash include/../scripts/tp_security_rbac.sh
set -e

echo "=== Creation d'un utilisateur Viewer ==="
airflow users create \
  --username analyste \
  --firstname Alex \
  --lastname Analyste \
  --role Viewer \
  --email analyste@snowystore.test \
  --password viewer123 || echo "(utilisateur deja existant)"

echo
echo "=== Roles disponibles ==="
airflow roles list

echo
echo "=== Utilisateurs ==="
airflow users list

cat <<'MSG'

------------------------------------------------------------------
A FAIRE MAINTENANT DANS L'INTERFACE :
  1. Se deconnecter du compte admin
  2. Se reconnecter avec  analyste / viewer123
  3. Essayer de : declencher un DAG   -> refuse
                  mettre en pause     -> refuse
                  voir Admin > Connections -> invisible ou refuse
                  consulter un DAG et ses logs -> autorise
  4. Se reconnecter en admin pour la suite de la formation

QUESTION DE SYNTHESE : quel role pour un analyste metier qui veut
seulement suivre l'etat des pipelines ? Pourquoi PAS Admin ?
------------------------------------------------------------------
MSG

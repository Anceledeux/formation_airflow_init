# Procédure d'installation de l'environnement — Formation Apache Airflow 3

Document destiné au **formateur** et aux **stagiaires**. À dérouler intégralement au moins
une fois **avant** la formation.

**Moteur de conteneurs retenu : Podman** (recommandé). Docker Desktop reste possible et
est documenté en annexe.

**Durée : 45 à 60 minutes** la première fois (dont 15 à 20 min de téléchargements).

---

## Sommaire

1. [Ce que l'on installe et pourquoi](#1-ce-que-lon-installe-et-pourquoi)
2. [Pourquoi Podman](#2-pourquoi-podman)
3. [Prérequis matériels](#3-prérequis-matériels)
4. [Installation sur Windows](#4-installation-sur-windows)
5. [Installation sur macOS](#5-installation-sur-macos)
6. [Installation sur Linux](#6-installation-sur-linux)
7. [Configurer l'Astro CLI pour Podman](#7-configurer-lastro-cli-pour-podman)
8. [Mise en place du projet de formation](#8-mise-en-place-du-projet-de-formation)
9. [Premier démarrage](#9-premier-démarrage)
10. [Vérification complète (checklist)](#10-vérification-complète-checklist)
11. [Commandes du quotidien](#11-commandes-du-quotidien)
12. [Résolution des problèmes](#12-résolution-des-problèmes)
13. [Contexte d'entreprise : proxy, VPN, droits](#13-contexte-dentreprise--proxy-vpn-droits)
14. [Désinstallation / remise à zéro](#14-désinstallation--remise-à-zéro)
- [Annexe A — Variante Docker Desktop](#annexe-a--variante-docker-desktop)
- [Annexe B — Les trois voies d'installation d'Airflow](#annexe-b--les-trois-voies-dinstallation-dairflow)
- [Annexe C — Versions utilisées](#annexe-c--versions-utilisées)

---

## 1. Ce que l'on installe et pourquoi

| Composant | Rôle | Obligatoire ? |
|-----------|------|---------------|
| **Podman** | moteur de conteneurs : Airflow tourne dans des conteneurs | **Oui** |
| **Astro CLI** | outil qui monte un Airflow complet en une commande | **Oui** |
| **Projet `snowystore-airflow`** | le projet de la formation (DAGs, données, corrigés) | **Oui** |
| **Python ≥ 3.12** | générer les données, lancer les tests hors conteneur | Recommandé |
| **IDE** (VS Code / PyCharm) | écrire les DAGs | Recommandé |
| **Client SQL** (DBeaver / psql) | inspecter la base DWH (TP10) | Optionnel |

**Ce que vous n'installez pas :** Airflow lui-même, PostgreSQL, Redis. Tout cela vit dans
les conteneurs gérés par l'Astro CLI. C'est l'intérêt de l'approche : rien ne pollue votre
machine, et un `astro dev kill` remet tout à zéro.

**Bonne nouvelle :** depuis la version 1.32, l'Astro CLI installé via **winget** (Windows)
ou **Homebrew** (macOS) **embarque Podman et le pré-configure**. Sur ces deux systèmes,
une seule commande installe donc les deux composants.

---

## 2. Pourquoi Podman

C'est l'option recommandée pour cette formation, pour trois raisons.

**Licence.** Docker Desktop est payant au-delà de 250 salariés ou 10 M$ de chiffre
d'affaires. Beaucoup d'entreprises n'ont pas la licence, et l'installer serait une
non-conformité. Podman est entièrement libre (Apache 2.0), sans restriction d'usage
commercial.

**Sécurité.** Podman fonctionne *rootless* et *daemonless* : pas de service privilégié qui
tourne en permanence en arrière-plan. C'est un argument qui passe mieux auprès des DSI, et
qui débloque souvent des situations où Docker Desktop est refusé.

**Compatibilité.** Podman implémente la même API que Docker. L'Astro CLI le pilote de façon
transparente, et les commandes `podman` reprennent la syntaxe `docker`. Concrètement, pour
la formation, **rien ne change** : le projet, les DAGs et les TP sont identiques.

> **Point d'honnêteté :** sur **Windows**, Podman passe par une machine virtuelle Linux et un
> tunnel SSH — une couche supplémentaire qui est une source de friction réelle (voir le
> dépannage « ssh: rejected »). Sur **Windows ARM64**, c'est encore moins éprouvé.
> Sur macOS et Linux, Podman est fiable.
>
> **Recommandation pratique :** testez Podman sur un poste Windows représentatif **avant** de
> l'imposer à tout un groupe. Si ça résiste, Docker Desktop (annexe A) est un repli parfaitement
> légitime — à condition que la licence le permette. Le projet et les TP sont identiques dans
> les deux cas.

---

## 3. Prérequis matériels

| Ressource | Minimum | Recommandé |
|-----------|---------|------------|
| RAM | 8 Go | **16 Go** |
| Disque libre | 10 Go | 20 Go |
| Processeur | 4 cœurs | 4 cœurs ou plus |
| Droits | **administrateur** (installation) | — |

Airflow 3 démarre plusieurs conteneurs simultanément (api-server, scheduler, triggerer,
dag-processor, Postgres de métadonnées, + le Postgres DWH de la formation). Sur 8 Go, cela
fonctionne mais il faut fermer les autres applications gourmandes.

**Ports qui doivent être libres :** `8080` (interface Airflow), `5432` (Postgres de
métadonnées), `5433` (Postgres DWH de la formation).

---

## 4. Installation sur Windows

Windows 10 (build 16299 ou supérieur) ou Windows 11.

### 4.1 Activer WSL 2

Podman s'appuie sur WSL 2. Ouvrez **PowerShell en tant qu'administrateur** :

```powershell
wsl --install
```

Puis **redémarrez la machine**. Après redémarrage :

```powershell
wsl --status
wsl --set-default-version 2
```

> Si `wsl --install` échoue avec une erreur de virtualisation, activez la virtualisation
> matérielle dans le BIOS/UEFI (*Intel VT-x*, *AMD-V* ou *SVM Mode* selon la machine).

### 4.2 Installer l'Astro CLI (avec Podman inclus)

Dans **PowerShell en tant qu'administrateur** :

```powershell
winget install -e --id Astronomer.Astro
```

Cette commande installe l'Astro CLI **et** un Podman pré-configuré.

**Fermez puis rouvrez PowerShell** (pour recharger le PATH), puis vérifiez :

```powershell
astro version
podman --version
```

> Si `astro` n'est pas reconnu après réouverture, ajoutez manuellement le dossier contenant
> `astro.exe` à la variable d'environnement `PATH`, puis redémarrez la session.

### 4.3 Si vous préférez installer Podman séparément

```powershell
winget install -e --id RedHat.Podman
```

Puis initialiser la machine virtuelle Podman :

```powershell
podman machine init
podman machine start
podman run --rm hello-world
```

### 4.4 Installer Python (recommandé)

```powershell
winget install -e --id Python.Python.3.12
```

Rouvrez PowerShell, puis : `python --version`

### 4.5 Choisir le bon dossier de travail

**Important pour les performances :** placez le projet dans votre dossier utilisateur
Windows (par exemple `C:\Users\<vous>\formation-airflow`). **Évitez les dossiers synchronisés
OneDrive/SharePoint** : ils provoquent des verrous de fichiers et des lenteurs importantes
avec les conteneurs.

### 4.6 Quel terminal utiliser sur Windows ?

| Usage | Terminal conseillé |
|-------|--------------------|
| Gestion de Podman (`podman machine list / start / stop / rm / set`) | **PowerShell** |
| Diagnostic d'une panne | **PowerShell** |
| Quotidien : `astro dev start/stop/restart/logs`, `git`, `python` | PowerShell **ou** Git Bash |
| Scripts `.ps1` | PowerShell |
| Scripts `.sh` | Git Bash ou WSL |
| Filtrer une sortie | PowerShell : `Select-String` · Git Bash : `grep` |

**PowerShell est la voie par défaut** de cette documentation : il est présent sur toutes les
machines Windows, sans installation.

**Git Bash fonctionne très bien** pour le travail quotidien, si vous le préférez. Deux réserves,
liées à MSYS (sa couche Unix) et non à Podman :

**1. Réécriture des chemins.** Git Bash convertit les chemins commençant par `/` en chemins
Windows, ce qui peut casser une commande contenant un chemin Linux absolu :

```bash
MSYS_NO_PATHCONV=1 astro dev bash -c "ls /usr/local/airflow/dags"
```

**2. Commandes interactives.** `astro dev bash`, `psql` et consorts ouvrent un terminal
interactif, mal géré par MSYS :

```bash
winpty astro dev bash
```

---

## 5. Installation sur macOS

### 5.1 Astro CLI (avec Podman inclus)

```bash
brew install astro
```

Depuis la version 1.32, cette formule installe **Podman par défaut** et le configure —
c'est exactement ce que l'on veut ici.

Vérification :

```bash
astro version
podman --version
```

### 5.2 Si vous installez Podman séparément

```bash
brew install podman
podman machine init
podman machine start
podman run --rm hello-world
```

> Sur Mac Apple Silicon, `podman machine init` crée une VM Linux ARM64 : c'est normal et
> transparent pour la formation.

### 5.3 Python

```bash
brew install python@3.12
python3 --version
```

---

## 6. Installation sur Linux

C'est le système où Podman est le plus simple : pas de machine virtuelle, exécution native.

### 6.1 Podman

```bash
# Ubuntu / Debian
sudo apt update && sudo apt install -y podman

# Fedora / RHEL / CentOS
sudo dnf install -y podman

podman --version
podman run --rm hello-world
```

Activer le socket compatible Docker (nécessaire à l'Astro CLI) :

```bash
systemctl --user enable --now podman.socket
systemctl --user status podman.socket
```

### 6.2 Astro CLI

```bash
curl -sSL install.astronomer.io | sudo bash -s
astro version
```

Si l'installation renvoie une erreur `mkdir` :

```bash
curl -sSL install.astronomer.io > godownloader.sh
cat godownloader.sh | sudo bash -s -- -b /usr/local/bin
```

### 6.3 Python

```bash
sudo apt update && sudo apt install -y python3.12 python3-pip
python3 --version
```

---

## 7. Configurer l'Astro CLI pour Podman

Étape **essentielle** : indiquer à l'Astro CLI d'utiliser Podman plutôt que Docker.

```bash
astro config set -g container.binary podman
```

L'option `-g` (global) applique le réglage à tous vos projets Astro.

Vérification :

```bash
astro config get -g container.binary
```

Doit afficher `podman`.

> **Sur Linux uniquement**, si Podman tourne en mode *rootless* et que l'Astro CLI ne le
> trouve pas, vous pouvez avoir besoin de préciser :
> ```bash
> astro config set -g duplicate_volumes false
> ```
> Ce réglage évite des erreurs de montage de volumes propres à certaines configurations
> rootless.

---

## 8. Mise en place du projet de formation

### 8.1 Récupérer le projet

Décompressez `snowystore-airflow.zip` dans votre dossier de travail, puis :

```bash
cd snowystore-airflow
```

Vous devez y voir : `dags/`, `include/`, `solutions/`, `tests/`, `scripts/`,
`Dockerfile`, `requirements.txt`, `airflow_settings.yaml`, `docker-compose.override.yml`.

> Le fichier `docker-compose.override.yml` (qui ajoute le Postgres DWH) fonctionne
> **également avec Podman** : l'Astro CLI l'interprète de la même façon. Son nom vient du
> format Compose, pas du moteur utilisé.

### 8.2 Lancer la vérification automatique

**Linux / macOS / WSL / Git Bash :**

```bash
./scripts/check_env.sh
```

Le script détecte indifféremment Podman ou Docker.

**Windows PowerShell** — utilisez la version PowerShell du script :

```powershell
.\scripts\check_env.ps1
```

> Les scripts existent en deux versions : `.sh` (Linux / macOS / WSL / Git Bash) et `.ps1`
> (Windows PowerShell). Un script `.sh` **ne s'exécute pas** dans PowerShell.

**Tout point marqué `[FAIL]` doit être réglé avant la formation.**

### 8.3 Générer les données du fil rouge

Les TP lisent un fichier de commandes par jour (`orders_YYYY-MM-DD.csv`).

```bash
python include/generate_orders.py --days 20
ls include/data | tail -3
```

> **Point d'attention (formateur) :** les corrigés utilisent `start_date=datetime(2026, 7, 20)`.
> Les dates générées doivent **couvrir la période jouée** pendant la formation, sinon les TP
> à partir du TP4 échoueront avec `FileNotFoundError`. Pour une plage précise :
> ```bash
> python include/generate_orders.py --start 2026-07-20 --end 2026-08-15
> ```

### 8.4 Faut-il un environnement virtuel Python (venv) ?

**Non — ce n'est pas nécessaire.** Airflow, PostgreSQL et toutes les dépendances (`pandas`,
les providers…) vivent **dans les conteneurs**, jamais sur votre machine. C'est précisément
l'intérêt de l'approche Astro + Podman : rien ne pollue votre poste.

Le seul script exécuté côté machine, `include/generate_orders.py`, n'utilise que la
**bibliothèque standard** de Python (`csv`, `random`, `datetime`, `pathlib`, `argparse`) :
aucune dépendance à installer, donc rien à isoler.

De même, les tests se lancent **dans le conteneur**, là où Airflow est déjà présent :

```bash
astro dev bash
pytest tests/ -v
```

#### Le cas où un venv est utile : le confort de l'IDE

Sans Airflow installé en local, votre éditeur soulignera en rouge les imports
`from airflow.sdk import dag, task` : imports non résolus, pas d'autocomplétion.
**Le code fonctionne parfaitement** (il s'exécute dans le conteneur), mais l'affichage peut
dérouter.

Si vous voulez l'autocomplétion — **optionnel, et à faire avant la formation, pas pendant** :

```bash
python -m venv venv
source venv/bin/activate          # Windows : venv\Scripts\activate
pip install "apache-airflow==3.3.0" \
  --constraint "https://raw.githubusercontent.com/apache/airflow/constraints-3.3.0/constraints-3.12.txt"
pip install apache-airflow-providers-postgres pandas pytest
```

Puis sélectionnez cet interpréteur dans votre IDE (VS Code : *Python: Select Interpreter*).

> Ce venv sert **uniquement** au confort d'édition et à d'éventuels tests locaux. Il ne joue
> aucun rôle dans l'exécution : c'est toujours l'Airflow du conteneur qui exécute vos DAGs.
> Ne pas le confondre avec l'installation classique par pip (annexe B), qui est une autre
> façon de *faire tourner* Airflow.

---

## 9. Premier démarrage

```bash
astro dev start
```

**La première exécution télécharge les images : comptez 5 à 15 minutes** selon la connexion.
Ensuite, le démarrage prend 30 à 60 secondes.

Ouvrez ensuite : **<http://localhost:8080>** — identifiants **`admin` / `admin`**

> **Si le port 8080 est occupé :**
> ```bash
> astro config set webserver.port 8081
> astro dev restart
> ```

### Ce que vous devez voir

- Le récapitulatif d'Astro : `Added Pool: dwh_pool`, `Added Connection: snowystore_dwh`, etc.
  — signe que `airflow_settings.yaml` a bien été pris en compte
- Sur Windows, un avertissement `could not start proxy: proxy daemon is not supported on
  Windows` : **sans effet, à ignorer**
- ⚠️ Astro n'affiche que le Postgres de **métadonnées** (port 5432). Notre base DWH est un
  service distinct, sur le port **5433** — le vérifier séparément :
  `podman ps` doit lister **postgres-dwh**
- L'interface Airflow 3 (React)
- **« Aucun DAG trouvé » : c'est normal.** Le dossier `dags/` est volontairement vide — ce sont
  les stagiaires qui écrivent leurs DAGs au fil des TP.
- Une **erreur d'importation de DAG** sur `snowystore_broken.py` : **normale et attendue**,
  ce fichier est volontairement cassé (support du TP debug du Jour 1). Cliquer sur le chevron
  affiche l'erreur — c'est ce que les stagiaires devront diagnostiquer.
- Pour voir un vrai DAG s'afficher, installer un corrigé :
  `Copy-Item solutions\tp01_snowystore_etl.py dags\` (PowerShell)
  ou `cp solutions/tp01_snowystore_etl.py dags/` (Bash)

---

## 10. Vérification complète (checklist)

| # | Vérification | Commande / action | Résultat attendu |
|---|--------------|-------------------|------------------|
| 1 | Moteur de conteneurs | `podman info` | pas d'erreur |
| 2 | Astro CLI | `astro version` | version affichée |
| 3 | Astro pointe sur Podman | `astro config get -g container.binary` | `podman` |
| 4 | Conteneurs démarrés | `podman ps` | api-server, scheduler, triggerer, dag-processor, postgres, **postgres-dwh** |
| 5 | Interface web | <http://localhost:8080> | connexion admin/admin OK |
| 6 | Version d'Airflow | `astro dev bash` puis `airflow version` | **3.x** |
| 7 | Données présentes | `ls include/data` | fichiers `orders_*.csv` |
| 8 | Connexions | UI → Admin → Connections | `snowystore_dwh` **et** `fs_default` présentes |
| 9 | Variables & pool | UI → Admin → Variables / Pools | `snowystore_config`, `dwh_pool` (2 slots) |
| 10 | Base DWH joignable | `psql -h localhost -p 5433 -U snowy -d snowystore` (mdp `snowy`) | invite `snowystore=#` |
| 11 | Tests | `astro dev bash` puis `pytest tests/ -v` | tests unitaires au vert |
| 12 | Un DAG s'exécute | UI → activer et déclencher un DAG | run vert |

> Au point **11**, `test_dag_integrity` peut échouer tant que `snowystore_broken.py` est
> présent : c'est **normal**, ce DAG est cassé exprès. Les tests de
> `test_transform_logic.py` doivent tous passer.

---

## 11. Commandes du quotidien

| Commande | Effet |
|----------|-------|
| `astro dev start` | démarre l'environnement |
| `astro dev stop` | arrête proprement, sans rien perdre |
| `astro dev restart` | **obligatoire après modification du `Dockerfile` ou de `requirements.txt`** |
| `astro dev kill` | détruit tout et repart de zéro (reset propre) |
| `podman machine stop astro-machine` | **libère la RAM** de la VM après `astro dev stop` |
| `wsl --shutdown` | Windows : rend toute la mémoire WSL au système |
| `astro dev bash` | ouvre un shell dans le conteneur (commandes `airflow …`) |
| `astro dev logs -f` | suit les logs en direct |
| `podman ps` | liste les conteneurs actifs |
| `podman machine start` | démarre la VM Podman (Windows/macOS, si elle est arrêtée) |

**Le piège classique :** ajouter un provider dans `requirements.txt` puis faire
`stop` + `start`. Cela ne reconstruit pas l'image, donc le provider n'apparaît pas.
Il faut **`astro dev restart`**.

---

## 12. Résolution des problèmes

| Symptôme | Cause probable | Solution |
|----------|----------------|----------|
| `this is not an Astro project directory` | mauvais dossier, ou `.astro/` absent | voir juste en dessous |
| `podman: command not found` | PATH non rechargé | rouvrir le terminal ; sinon réinstaller |
| `Cannot connect to Podman` | VM Podman arrêtée (Windows/macOS) | `podman machine start` |
| `ssh: rejected: connect failed` | **deux machines Podman actives**, ou tunnel SSH | voir les deux sections ci-dessous |
| `VM already exists` | `podman machine init` inutile | l'Astro CLI gère `astro-machine` lui-même |
| `astro: command not found` | PATH non rechargé | rouvrir le terminal ; ajouter le dossier d'`astro` au PATH |
| Astro cherche Docker au lieu de Podman | configuration non appliquée | `astro config set -g container.binary podman` |
| `port 8080 already in use` | autre service sur ce port | `astro config set webserver.port 8081` puis `astro dev restart` |
| `port 5433 already in use` | un autre Postgres tourne | changer le port hôte dans `docker-compose.override.yml` |
| Erreurs de montage de volumes (Linux rootless) | permissions rootless | `astro config set -g duplicate_volumes false` |
| Démarrage très long puis échec | RAM insuffisante | fermer les applications ; **Windows** : `.wslconfig` (voir § 7) · **macOS** : `podman machine set --memory 8192` |
| `changing CPUs not supported for WSL machines` | ressources gérées par WSL, pas par Podman | passer par `.wslconfig` (voir § 7) |
| `could not start proxy: proxy daemon is not supported on Windows` | avertissement sans effet | **à ignorer** |
| `error pulling image` / timeout | proxy ou firewall d'entreprise | voir section 13 |
| `FileNotFoundError: orders_….csv` | données non générées ou dates hors plage | `python include/generate_orders.py --days 30` |
| Un DAG n'apparaît jamais | erreur d'import, ou pas encore sérialisé | `astro dev bash` puis `airflow dags list-import-errors` et `airflow dags reserialize` |
| `bash: airflow: command not found` | vous êtes sur votre machine, pas dans le conteneur | `astro dev bash` d'abord — voir `LE_CONTENEUR.md` |
| Un DAG existe mais ne se déclenche jamais | `start_date` dynamique (`datetime.now()`) | mettre une date **fixe** |
| Provider introuvable après ajout | image non reconstruite | `astro dev restart` |
| Connexion DWH refusée | conteneur `postgres-dwh` absent | `podman ps` ; `astro dev restart` |
| `failed to resolve host 'postgres-dwh'` | le DWH n'est pas sur le réseau `airflow` | `docker-compose.override.yml` doit contenir `networks: [airflow]`, puis `astro dev restart` · diagnostic : `./scripts/check_dwh.sh` |
| Tout est cassé, on ne sait plus pourquoi | — | `astro dev kill` puis `astro dev start` |

### « this is not an Astro project directory »

L'Astro CLI reconnaît un projet à la présence du fichier **`.astro/config.yaml`**. Deux causes :

**1. Vous n'êtes pas dans le bon dossier.** Après décompression, l'archive crée souvent un
dossier imbriqué (`snowystore-airflow/snowystore-airflow`). Le bon dossier est celui qui
contient le `Dockerfile` :

```bash
ls           # doit afficher : Dockerfile  dags  include  requirements.txt ...
ls -a        # doit afficher aussi : .astro
```

Si `ls` ne montre pas le `Dockerfile`, descendez d'un niveau : `cd snowystore-airflow`.

**2. Le dossier `.astro` est absent** (archive ancienne, ou dossier masqué perdu à la copie).
Le recréer prend dix secondes :

```bash
mkdir -p .astro
printf 'project:\n  name: snowystore-airflow\n' > .astro/config.yaml
astro dev start
```

Autre solution, équivalente : `astro dev init` dans le dossier existant. La commande complète
les fichiers manquants **sans écraser** vos `dags/` — répondez `y` si elle demande confirmation
sur un dossier non vide.

### Plusieurs machines Podman : le conflit à connaître

**Symptôme :** `ssh: rejected: connect failed`, ou un comportement erratique de `astro dev start`.

**Cause :** l'Astro CLI crée et gère **sa propre machine, `astro-machine`**. Si vous aviez déjà
une machine Podman (`podman-machine-default`, pour d'autres projets), **deux VM WSL tournent
en parallèle** et la connexion par défaut devient ambiguë.

```powershell
podman machine list
# NAME                     VM TYPE   LAST UP
# astro-machine*           wsl       Currently running
# podman-machine-default   wsl       Currently running     <-- le conflit
```

**Règle : une seule machine active à la fois.**

```powershell
podman machine stop podman-machine-default    # on garde la sienne, mais arrêtée
astro dev start                               # l'Astro CLI (re)crée astro-machine
```

> **Ne lancez pas `podman machine init`** pour Airflow : l'Astro CLI s'en charge. Sans nom,
> cette commande tente de recréer `podman-machine-default` et échoue avec
> `VM already exists`. Et l'Astro CLI ne sait pas utiliser une machine existante.

**Machine dédiée à Airflow.** `astro-machine` *est* cette machine dédiée : elle est séparée de
votre machine personnelle, qui reste disponible pour vos autres projets (une seule active à la
fois). Astro la crée avec 4 Gio, le minimum requis — un peu juste avec nos six conteneurs plus
le Postgres du DWH. Si votre poste a 16 Go :

```powershell
podman machine stop astro-machine
podman machine set astro-machine --memory 8192 --cpus 4
podman machine start astro-machine
```

> ⚠️ **Sur Windows, cette commande échoue** avec `changing CPUs not supported for WSL machines`.
> C'est normal : les machines WSL ne gèrent pas leurs ressources individuellement, WSL les
> alloue globalement. Voir juste en dessous.

#### Régler la mémoire sur Windows (WSL)

Créer ou modifier `C:\Users\<vous>\.wslconfig` :

```ini
[wsl2]
memory=8GB
processors=4
```

Puis appliquer :

```powershell
wsl --shutdown
astro dev start
```

> Ce réglage s'applique à **toutes** vos distributions WSL, pas seulement à `astro-machine`.
> Par défaut, WSL s'autorise déjà jusqu'à **50 % de la RAM** de la machine : sur un poste de
> 16 Go, vous avez donc probablement déjà 8 Go et ce réglage est **facultatif**. Ne l'appliquer
> qu'en cas de lenteurs ou de conteneurs qui s'arrêtent seuls.

**Vérification finale**

```powershell
podman machine list             # une seule "Currently running"
podman system connection list   # l'étoile (*) sur astro-machine
podman ps                       # doit répondre sans erreur
```

### « unable to connect to Podman socket: ssh: rejected »

Symptôme : la machine Astro s'initialise (`Astro machine initialized`), puis la connexion à
la VM Podman échoue. C'est un cas **connu de Podman sur Windows** : la VM tourne, mais le
tunnel SSH ne s'établit pas.

À dérouler dans cet ordre :

**0. Vérifier qu'une seule machine Podman tourne** (`podman machine list`) — voir la section
précédente. C'est la cause la plus fréquente si vous aviez déjà Podman installé.

**1. Quitter Git Bash, passer en PowerShell.** Git Bash / MSYS réécrit les chemins Windows et
casse fréquemment les connexions SSH de Podman. Beaucoup de cas se résolvent ainsi.

**2. Créer le dossier `.ssh`** — cause la plus fréquente depuis Podman 5.3 : Podman tente
d'écrire `known_hosts` dans un dossier inexistant, et la connexion est rejetée.

```powershell
mkdir "$env:USERPROFILE\.ssh" -Force
podman machine stop
podman machine start
podman run --rm hello-world
```

**3. Diagnostiquer**

```powershell
podman machine list              # la machine existe-t-elle, est-elle "Currently running" ?
podman system connection list    # quelle URI, quel port ?
podman machine ssh               # si cela fonctionne, le problème est le tunnel côté client
```

**4. Recréer la machine**

```powershell
podman machine rm astro-machine -f     # nom vu dans 'podman machine list'
podman machine init
podman machine start
astro dev start
```

**5. Bascule vers Docker** — plan B assumé, si le temps presse :

```powershell
astro config set -g container.binary docker
astro dev start
```

Le projet, les DAGs et les TP sont **identiques** : seul le moteur de conteneurs change.

> ⚠️ **Windows ARM64** (processeurs Snapdragon, Surface ARM…) : Podman y fonctionne, mais la
> configuration est nettement moins éprouvée que sur x86 — les tunnels SSH et le proxy
> `win-sshproxy.exe` y posent plus souvent problème. Sur ce matériel, **prévoir Docker Desktop
> en secours** et le tester avant la formation.

### Redimensionner la machine virtuelle Podman (Windows / macOS)

Si Airflow rame ou si des conteneurs meurent au démarrage :

```bash
podman machine stop
podman machine set --memory 8192 --cpus 4
podman machine start
```

### Réinitialisation totale

```bash
astro dev kill
astro dev start
```

Cela efface la base de métadonnées (historique des runs), mais **pas vos fichiers** dans
`dags/` et `include/`.

---

## 13. Contexte d'entreprise : proxy, VPN, droits

C'est **la première cause d'échec** en intra-entreprise. À traiter **avant** le jour de la
formation, avec la DSI si nécessaire.

**Droits administrateur** — nécessaires pour installer WSL et Podman. Si vous ne les avez
pas, faites la demande en amont : ce n'est pas contournable le jour J.

**Proxy / firewall** — le moteur de conteneurs doit pouvoir télécharger depuis :

- `astrocrpublic.azurecr.io` (images Astro Runtime pour Airflow 3)
- `docker.io` / `registry-1.docker.io` (image Postgres, etc.)
- `quay.io` (certaines images de base)

Test décisif :

```bash
podman pull hello-world
podman pull postgres:16
```

En cas de blocage, configurez le proxy pour Podman (variables `HTTP_PROXY` / `HTTPS_PROXY`
dans la VM Podman, ou dans `containers.conf`), ou demandez à la DSI l'ouverture de ces
domaines.

**Antivirus** — certains antivirus d'entreprise bloquent les montages de volumes.
Symptôme typique : les conteneurs démarrent mais ne voient pas vos fichiers.

**Plan de secours** — si le poste reste bloqué le jour J : travail en binôme sur un poste
fonctionnel, ou environnement cloud pré-provisionné (compte d'essai Astro Cloud).

---

## 14. Désinstallation / remise à zéro

**Nettoyer uniquement le projet :**

```bash
astro dev kill
```

**Libérer l'espace disque :**

```bash
podman system prune -a --volumes
```

> Attention : supprime **toutes** les images et volumes inutilisés de la machine.

**Supprimer la VM Podman (Windows/macOS) :**

```bash
podman machine stop
podman machine rm
```

**Désinstaller complètement :**

```powershell
# Windows
winget uninstall Astronomer.Astro
winget uninstall RedHat.Podman
```

```bash
# macOS
brew uninstall astro podman
```

---

## Annexe A — Variante Docker Desktop

Si un poste résiste avec Podman, ou si votre entreprise dispose déjà d'une licence Docker.

1. Installer Docker Desktop : <https://www.docker.com/products/docker-desktop/>
   (sur Windows, cocher **« Use WSL 2 instead of Hyper-V »**)
2. Lancer l'application et attendre l'état *Engine running*
3. Basculer l'Astro CLI sur Docker :

```bash
astro config set -g container.binary docker
docker info
astro dev start
```

Pour éviter d'installer Podman en même temps que l'Astro CLI sur macOS :

```bash
brew install astronomer/tap/astro --without-podman
```

(l'option n'existe que sur la formule du tap Astronomer, pas sur Homebrew core).

> **Rappel licence :** Docker Desktop est payant au-delà de 250 salariés ou 10 M$ de CA.
> Vérifiez auprès de votre DSI avant de l'installer en entreprise.

---

## Annexe B — Les trois voies d'installation d'Airflow

Cette formation utilise **Astro CLI**, mais le programme couvre les trois approches.
Vous n'avez **rien à installer** pour les deux premières : elles sont présentées à titre
de comparaison (section 2 du programme).

**1. Installation classique (pip)** — pour comprendre ce qu'il y a sous le capot :

```bash
python -m venv venv && source venv/bin/activate
pip install "apache-airflow==3.3.0" \
  --constraint "https://raw.githubusercontent.com/apache/airflow/constraints-3.3.0/constraints-3.12.txt"
airflow standalone
```

Le fichier de **constraints** est obligatoire : sans lui, les dépendances entrent en conflit.

**2. Docker Compose officiel** — proche de la production, verbeux à configurer.
Utilisé en lecture au TP11 pour identifier l'architecture CeleryExecutor.

**3. Astro CLI** — retenue ici : projet standardisé, versions figées dans le `Dockerfile`,
environnement reproductible d'un poste à l'autre.

---

## Annexe C — Versions utilisées

| Élément | Version |
|---------|---------|
| Apache Airflow | **3.3.x** |
| Astro Runtime | **3.3** (`astrocrpublic.azurecr.io/runtime:3.3`) |
| Moteur de conteneurs | **Podman** (Docker Desktop en alternative) |
| PostgreSQL (DWH de formation) | 16 |

> **Registre d'images :** depuis Airflow 3, les images Astro Runtime sont hébergées sur
> `astrocrpublic.azurecr.io/runtime:` — et non plus sur `quay.io/astronomer/astro-runtime`,
> qui reste le registre des images Airflow 2.x. Un `FROM` pointant vers l'ancien registre
> avec un tag Airflow 3 échouera.
>
> Le tag `3.3` (sans numéro de patch) suit toujours le dernier correctif de la version 3.3.
> Si ce tag n'était pas disponible, utilisez `3.2` : les TP sont compatibles avec les deux.
>
> **Providers :** depuis Astro Runtime 3.0, les images ne contiennent que les providers
> nécessaires. Tout ajout se déclare dans `requirements.txt`, suivi d'un `astro dev restart`.

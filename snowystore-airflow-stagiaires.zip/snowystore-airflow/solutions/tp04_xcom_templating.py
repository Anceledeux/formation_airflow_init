"""TP4 — XCom + templating Jinja.

  - extract compte les lignes du fichier du jour et transmet le compte (XCom)
  - le chemin d'entree est dynamique : orders_{{ ds }}.csv
  - data_interval_start est affiche dans les logs
"""
from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path

from airflow.sdk import dag, task
from airflow.providers.standard.operators.bash import BashOperator

DATA_DIR = Path("/usr/local/airflow/include/data")


@dag(
    dag_id="snowystore_xcom_templating",
    start_date=datetime(2026, 7, 20),
    schedule="@daily",
    catchup=False,
    default_args={"owner": "formation", "retries": 1},
    tags=["snowystore", "tp4"],
)
def snowystore_xcom_templating():

    @task
    def extract(**context) -> int:
        """Lit orders_<ds>.csv et renvoie le nombre de lignes (XCom)."""
        ds = context["ds"]
        path = DATA_DIR / f"orders_{ds}.csv"
        if not path.exists():
            raise FileNotFoundError(
                f"{path} introuvable — generer les donnees : python include/generate_orders.py"
            )
        with path.open(encoding="utf-8") as fh:
            n_rows = sum(1 for _ in csv.DictReader(fh))
        print(f"{n_rows} lignes extraites de {path.name}")
        return n_rows

    @task
    def load(n_rows: int, **context) -> int:
        print(f"Chargement de {n_rows} lignes (intervalle : {context['data_interval_start']})")
        return n_rows

    @task
    def notify(n_rows: int) -> None:
        print(f"Pipeline termine : {n_rows} lignes chargees")

    # Le champ bash_command est template : {{ ds }} est remplace a l'execution.
    show_date = BashOperator(
        task_id="show_date",
        bash_command="echo 'Fichier vise : orders_{{ ds }}.csv | interval start {{ data_interval_start }}'",
    )

    rows = extract()
    show_date >> rows
    notify(load(rows))


snowystore_xcom_templating()

<#
.SYNOPSIS
    Raccourci pour interroger le DWH Snowystore (equivalent de dwh.sh).
.EXAMPLE
    .\scripts\dwh.ps1                 # session psql interactive
    .\scripts\dwh.ps1 -Mart           # contenu de mart_daily_sales
    .\scripts\dwh.ps1 -Check          # test d'idempotence
    .\scripts\dwh.ps1 "SELECT 1;"     # requete libre
#>
param(
    [Parameter(Position = 0)][string]$Sql,
    [switch]$Mart,
    [switch]$Check,
    [switch]$Staging
)

$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")

$engine = if (Get-Command podman -ErrorAction SilentlyContinue) { "podman" } else { "docker" }
$cid = (& $engine ps -qf name=postgres-dwh | Select-Object -First 1)

if (-not $cid) {
    Write-Host "Conteneur postgres-dwh introuvable. Lancer : astro dev start" -ForegroundColor Red
    exit 1
}

if ($Mart)    { $Sql = "SELECT sale_date, category, total_amount FROM mart_daily_sales ORDER BY sale_date DESC, total_amount DESC LIMIT 20;" }
elseif ($Check) {
    $Sql = "SELECT sale_date, COUNT(*) AS nb_categories, SUM(total_amount) AS total FROM mart_daily_sales GROUP BY sale_date ORDER BY sale_date DESC LIMIT 10;"
    Write-Host "Test d'idempotence : relancez le MEME run, puis rejouez cette commande."
    Write-Host "Les valeurs doivent etre IDENTIQUES, pas doublees.`n" -ForegroundColor Cyan
}
elseif ($Staging) { $Sql = "SELECT load_date, COUNT(*) AS nb_lignes FROM staging_orders GROUP BY load_date ORDER BY load_date DESC LIMIT 10;" }

if ([string]::IsNullOrWhiteSpace($Sql)) {
    & $engine exec -it $cid psql -U snowy -d snowystore
} else {
    & $engine exec $cid psql -U snowy -d snowystore -c $Sql
}

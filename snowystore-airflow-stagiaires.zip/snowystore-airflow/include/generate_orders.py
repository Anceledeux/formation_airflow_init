"""Generateur de donnees du fil rouge Snowystore.

Produit un fichier CSV de commandes par jour : include/data/orders_YYYY-MM-DD.csv
Colonnes : order_id, customer_id, product_id, category, amount, order_ts

Usage :
    python include/generate_orders.py                 # 10 jours jusqu'a hier
    python include/generate_orders.py --days 30
    python include/generate_orders.py --start 2026-06-01 --end 2026-06-10
    python include/generate_orders.py --anomalies     # injecte un montant negatif (TP qualite)
"""
from __future__ import annotations

import argparse
import csv
import random
from datetime import date, datetime, timedelta
from pathlib import Path

DATA_DIR = Path(__file__).parent / "data"
CATEGORIES = ["ski", "snowboard", "textile", "accessoires", "chaussures"]
ROWS_PER_DAY = (800, 1200)


def generate_day(day: date, seed_offset: int = 0, anomalies: bool = False) -> Path:
    """Genere le CSV d'une journee. Deterministe : meme date => memes donnees."""
    rng = random.Random(day.toordinal() + seed_offset)
    n_rows = rng.randint(*ROWS_PER_DAY)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    path = DATA_DIR / f"orders_{day.isoformat()}.csv"

    with path.open("w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow(["order_id", "customer_id", "product_id", "category", "amount", "order_ts"])
        for i in range(n_rows):
            category = rng.choice(CATEGORIES)
            amount = round(rng.uniform(15, 450), 2)
            hour, minute, second = rng.randint(0, 23), rng.randint(0, 59), rng.randint(0, 59)
            writer.writerow([
                f"{day.isoformat()}-{i:05d}",
                f"CUST{rng.randint(1, 5000):05d}",
                f"PROD{rng.randint(1, 400):04d}",
                category,
                amount,
                f"{day.isoformat()} {hour:02d}:{minute:02d}:{second:02d}",
            ])
        if anomalies:
            # Ligne volontairement invalide pour le TP "data quality".
            writer.writerow([f"{day.isoformat()}-BAD", "CUST00001", "PROD0001", "ski", -99.99,
                             f"{day.isoformat()} 12:00:00"])
    return path


def main() -> None:
    parser = argparse.ArgumentParser(description="Generateur de commandes Snowystore")
    parser.add_argument("--days", type=int, default=10, help="nombre de jours a generer (jusqu'a AUJOURD'HUI inclus)")
    parser.add_argument("--ahead", type=int, default=2,
                        help="jours generes APRES aujourd'hui (marge pour les declenchements manuels)")
    parser.add_argument("--start", type=str, help="date de debut incluse (YYYY-MM-DD)")
    parser.add_argument("--end", type=str, help="date de fin incluse (YYYY-MM-DD)")
    parser.add_argument("--anomalies", action="store_true", help="injecte une ligne invalide par fichier")
    args = parser.parse_args()

    if args.start and args.end:
        start = datetime.strptime(args.start, "%Y-%m-%d").date()
        end = datetime.strptime(args.end, "%Y-%m-%d").date()
    else:
        # On genere jusqu'a aujourd'hui + une marge.
        # POURQUOI : un declenchement MANUEL porte la date du JOUR. Si les donnees
        # s'arretaient a hier, tout DAG lisant orders_{{ ds }}.csv (FileSensor du projet
        # final, TP4, TP10...) attendrait un fichier inexistant.
        end = date.today() + timedelta(days=args.ahead)
        start = date.today() - timedelta(days=args.days - 1)

    current, created = start, []
    while current <= end:
        created.append(generate_day(current, anomalies=args.anomalies))
        current += timedelta(days=1)

    print(f"{len(created)} fichier(s) generes dans {DATA_DIR}")
    print(f"  du {start.isoformat()} au {end.isoformat()}")
    if created:
        print(f"  exemple : {created[-1].name}")


if __name__ == "__main__":
    main()

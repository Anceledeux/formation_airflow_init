# Snowystore Airflow — Projet de la formation Apache Airflow 3

Projet Astro complet du fil rouge **Snowystore** (e-commerce fictif) : on construit
brique par brique, sur 3 jours, un pipeline ETL réel, idempotent et prêt pour la production.

---

> **Formateur :** pour publier et distribuer ce projet, voir **[DISTRIBUTION.md](DISTRIBUTION.md)**.

> **Airflow tourne dans des conteneurs.** Quand faut-il y entrer, comment, pourquoi ?
> → **[LE_CONTENEUR.md](LE_CONTENEUR.md)** (à lire au TP0).

> **Premier jour de formation ?** Commencez par **[DEMARRAGE_JOUR1.md](DEMARRAGE_JOUR1.md)**
> — mise en place du projet en 10 minutes.

> **Vous préparez votre poste avant la formation ?** Suivez **[AVANT_LA_FORMATION.md](AVANT_LA_FORMATION.md)**
> — version courte et actionnable (45 min).

> **Première installation ?** Suivez la procédure complète pas à pas :
> **[INSTALLATION.md](INSTALLATION.md)** (Windows / macOS / Linux, dépannage, proxy d'entreprise).

## 1. Avant la formation (à faire 3 jours avant)

```bash
./scripts/check_env.sh        # Linux / macOS / WSL / Git Bash
```
```powershell
.\scripts\check_env.ps1       # Windows PowerShell
```

Le script vérifie Podman/Docker, l'Astro CLI, Python, les ports 8080/5432/5433, la RAM
et l'accès au registre d'images. **Signalez tout point bloquant avant le jour J** :
les blocages Docker en entreprise (proxy, droits admin) se règlent avec la DSI, pas en séance.

Prérequis : **Podman** (recommandé — libre, rootless, sans contrainte de licence) ou Docker Desktop · Python ≥ 3.12 · un IDE · 8 Go de RAM (16 Go recommandés).

## 2. Démarrer

```bash
./scripts/generate_data.sh 15     # génère 15 jours de commandes dans include/data/
astro dev start                   # UI : http://localhost:8080  (admin / admin)
```

Commandes utiles :

| Commande | Effet |
|----------|-------|
| `astro dev start` | démarre l'environnement |
| `astro dev stop` | arrête sans rien perdre (la VM Podman garde sa RAM) |
| `astro dev stop` + `podman machine stop astro-machine` | arrête **et libère la mémoire** |
| `astro dev restart` | **après modification du Dockerfile ou de requirements.txt** |
| `astro dev kill` | remet à zéro (reset propre) |
| `astro dev bash` | ouvre un shell dans le conteneur (pour les commandes `airflow …`) |
| `astro dev logs -f` | suit les logs |

## 3. Arborescence

```
LE_CONTENEUR.md           quand/comment entrer dans le conteneur
dags/                     vos DAGs (c'est ici que vous travaillez)
                          VIDE au depart : vous ecrivez vos DAGs au fil des TP
  snowystore_broken.py    DAG sabote du TP debug (J1) — a corriger
include/
  generate_orders.py      generateur des CSV de commandes
  transform_logic.py      logique metier factorisee (testable sans Airflow)
  config/                 configurations par environnement (TP8)
  data/                   CSV generes : orders_YYYY-MM-DD.csv
solutions/                CORRIGES de chaque TP (points de reprise)
tests/                    tests d'integrite + tests unitaires
scripts/                  outillage (env, donnees, reprise, TP securite)
.github/workflows/ci.yml  CI prete a l'emploi
airflow_settings.yaml     connexion / variables / pool provisionnes automatiquement
docker-compose.override.yml   Postgres cible du DWH (port 5433)
```

## 4. Points de reprise — personne ne reste bloqué

Le fil rouge est **cumulatif** : chaque TP repart du précédent. Si vous ratez une étape,
vous n'êtes pas coincé pour trois jours — installez le corrigé et repartez :

```bash
./scripts/reset_tp.sh --list     # liste les points de reprise
./scripts/reset_tp.sh tp05       # installe le corrigé du TP5 dans dags/
```
```powershell
.\scripts\reset_tp.ps1 -List    # Windows PowerShell
.\scripts\reset_tp.ps1 tp05
```
> Sans script, la copie manuelle fonctionne tout aussi bien :
> `Copy-Item solutions\tp05_factorisation.py dags\`

Votre travail précédent est sauvegardé dans `dags/_backup/`.

> **Conseil :** cherchez d'abord, appelez le formateur ensuite, et n'utilisez le corrigé
> qu'en dernier recours — mais utilisez-le sans culpabilité plutôt que de décrocher.

## 5. Se connecter à la base DWH

Le Postgres cible tourne sur le port **5433** (le 5432 est celui des métadonnées d'Airflow) :

```bash
./scripts/dwh.sh                    # session psql interactive
./scripts/dwh.sh --mart             # contenu de mart_daily_sales
./scripts/dwh.sh --check            # test d'idempotence (TP10)
./scripts/dwh.sh "SELECT 1;"        # requête libre
```

Ou directement, avec un client SQL installé sur votre machine (DBeaver, psql) :

```bash
psql -h localhost -p 5433 -U snowy -d snowystore     # mot de passe : snowy
```

Dans Airflow, la connexion est déjà provisionnée sous le `conn_id` **`snowystore_dwh`**.

## 6. Quel terminal ? (Windows)

**PowerShell** pour gérer Podman (`podman machine …`) et pour les scripts `.ps1`.
**Git Bash** convient au quotidien (`astro dev …`, `git`, `python`) et aux scripts `.sh`.

> Sous Git Bash, deux réflexes : `winpty astro dev bash` pour les commandes interactives, et
> `MSYS_NO_PATHCONV=1` devant une commande contenant un chemin Linux absolu.

## 7. Pas besoin de venv

Airflow et ses dépendances vivent **dans les conteneurs**. Le générateur de données n'utilise
que la bibliothèque standard. Vous n'avez donc **aucun environnement virtuel à créer**.

> Vos imports `from airflow.sdk import ...` seront peut-être soulignés en rouge dans l'éditeur :
> c'est normal, le code s'exécute dans le conteneur. Pour avoir l'autocomplétion, voir
> [INSTALLATION.md § 8.4](INSTALLATION.md) (optionnel).

## 8. Lancer les tests

```bash
astro dev bash
pytest tests/ -v
```

## 9. Correspondance TP → corrigé

| TP | Sujet | Corrigé |
|----|-------|---------|
| TP1 | Premier DAG (classique) | `solutions/tp01_snowystore_etl.py` |
| TP1 bis | Réécriture TaskFlow | `solutions/tp01bis_taskflow.py` |
| TP2 | Scheduling, catchup, backfill | `solutions/tp02_scheduling.py` |
| TP2 bis | Debug du DAG saboté | `solutions/tp02bis_debug_corrige.py` |
| TP3 | Assets producteur/consommateur | `solutions/tp03_assets.py` |
| TP3 bis | Sensor & mode reschedule | `solutions/tp03bis_sensor.py` |
| *(démo)* | Les 3 modes de sensor côte à côte | `solutions/demo_sensors_modes.py` |
| TP4 | XCom + templating Jinja | `solutions/tp04_xcom_templating.py` |
| TP5 | Factorisation + gestion d'erreurs | `solutions/tp05_factorisation.py` |
| TP6 | Tests | `tests/test_dag_integrity.py`, `tests/test_transform_logic.py` |
| TP7 | Branching, TaskGroups, mapping | `solutions/tp07_advanced.py` |
| TP8 | Variables & multi-environnements | `solutions/tp08_variables_config.py` |
| TP9 | Asset Approach (chaîne complète) | `solutions/tp09_asset_chain.py` |
| TP10 | ETL Postgres idempotent + pool | `solutions/tp10_etl_postgres.py` |
| TP11 | Laboratoire de concurrence | `solutions/tp11_concurrency_lab.py` |
| TP Sécurité | RBAC en pratique | `scripts/tp_security_rbac.sh` |
| TP12 | Projet final consolidé | `solutions/tp12_final_project.py` |

## 10. Problèmes fréquents

| Symptôme | Cause probable | Solution |
|----------|----------------|----------|
| `this is not an Astro project directory` | mauvais dossier, ou `.astro/` absent | `ls -a` doit montrer `.astro` et `Dockerfile` ; sinon voir [INSTALLATION.md](INSTALLATION.md) |
| Tous les DAGs se lancent au démarrage | ils étaient restés activés (état stocké en base) | `./scripts/pause_all.sh` avant `astro dev stop`, ou `astro dev kill` |
| Les tâches restent « en file », rien ne démarre | **le DAG est en pause** | activer l'interrupteur, ou cocher « Réactiver … lors du déclenchement » |
| Le DAG n'apparaît pas | erreur d'import, ou pas encore sérialisé | dans le conteneur : `airflow dags list-import-errors` puis `airflow dags reserialize` — voir [LE_CONTENEUR.md](LE_CONTENEUR.md) § 7 |
| `The conn_id 'fs_default' isn't defined` | connexion `fs` requise par le FileSensor absente | elle est provisionnée dans `airflow_settings.yaml` → `astro dev restart` |
| `FileNotFoundError: orders_….csv` · sensor qui attend indéfiniment | données non générées, ou date hors plage (un **déclenchement manuel** porte la date du **jour**) | `python include/generate_orders.py --days 20` |
| Le DAG ne se déclenche jamais | `start_date` dynamique | mettre une date **fixe** |
| Un provider n'est pas reconnu | image non reconstruite | `astro dev restart` (pas `stop`/`start`) |
| Port 8080 occupé | autre service | libérer le port ou `astro config set webserver.port 8081` |
| Connexion DWH refusée | Postgres cible non démarré | vérifier `podman ps` ; `astro dev restart` |
| `failed to resolve host 'postgres-dwh'` | DWH hors du réseau `airflow` | lancer `./scripts/check_dwh.sh` ; vérifier `networks: [airflow]` dans `docker-compose.override.yml` |

> Les imports d'operators peuvent varier légèrement selon la version d'Airflow 3.
> En cas d'erreur d'import, vérifier la version (`astro dev bash` puis `airflow version`)
> et consulter la documentation du provider correspondant.

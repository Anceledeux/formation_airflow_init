#!/usr/bin/env bash
# Verifie que le Postgres du DWH est joignable DEPUIS les conteneurs Airflow.
# A lancer si le TP10 echoue avec : failed to resolve host 'postgres-dwh'
set -u
cd "$(dirname "$0")/.."
ENGINE=$(command -v podman >/dev/null 2>&1 && echo podman || echo docker)

echo "=== 1. Le conteneur postgres-dwh tourne-t-il ? ==="
DWH=$($ENGINE ps --format "{{.Names}}" | grep postgres-dwh || true)
if [ -z "$DWH" ]; then
  echo "[FAIL] postgres-dwh introuvable -> astro dev restart"
  exit 1
fi
echo "[ OK ] $DWH"

echo
echo "=== 2. Reseaux ==="
SCHED=$($ENGINE ps --format "{{.Names}}" | grep scheduler | head -1)
echo "scheduler    : $($ENGINE inspect "$SCHED" --format '{{range $k,$v := .NetworkSettings.Networks}}{{$k}} {{end}}')"
echo "postgres-dwh : $($ENGINE inspect "$DWH" --format '{{range $k,$v := .NetworkSettings.Networks}}{{$k}} {{end}}')"
echo "(les deux doivent partager au moins un reseau)"

echo
echo "=== 3. Resolution du nom depuis le scheduler ==="
if $ENGINE exec "$SCHED" python -c "import socket;print(socket.gethostbyname('postgres-dwh'))" 2>/dev/null; then
  echo "[ OK ] 'postgres-dwh' est resolvable depuis Airflow"
else
  echo "[FAIL] nom non resolvable"
  echo "       -> verifier que docker-compose.override.yml contient  networks: [airflow]"
  echo "       -> puis : astro dev restart"
  exit 1
fi

echo
echo "=== 4. Connexion SQL ==="
if $ENGINE exec "$DWH" psql -U snowy -d snowystore -c "SELECT 1;" >/dev/null 2>&1; then
  echo "[ OK ] la base snowystore repond"
else
  echo "[FAIL] la base ne repond pas"
  exit 1
fi
echo
echo "Tout est bon : le TP10 peut se lancer."

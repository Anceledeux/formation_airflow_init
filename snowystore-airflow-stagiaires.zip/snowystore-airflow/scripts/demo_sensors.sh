#!/usr/bin/env bash
# Pilote la demo des 3 modes de sensor (Jour 2).
#   ./scripts/demo_sensors.sh reset     # supprime le fichier attendu (avant la demo)
#   ./scripts/demo_sensors.sh go        # cree le fichier (debloque les 3 sensors)
set -u
cd "$(dirname "$0")/.."
F="include/data/demo_sensors.txt"

case "${1:-}" in
  reset)
    rm -f "$F"
    echo "Fichier supprime : les sensors vont attendre."
    echo "-> installer le DAG :  cp solutions/demo_sensors_modes.py dags/"
    echo "-> puis l'activer et le declencher dans l'interface."
    ;;
  go)
    mkdir -p include/data && touch "$F"
    echo "Fichier cree : les 3 sensors se debloquent a leur prochaine verification (~15 s)."
    ;;
  *)
    echo "Usage : $0 {reset|go}"
    exit 1
    ;;
esac

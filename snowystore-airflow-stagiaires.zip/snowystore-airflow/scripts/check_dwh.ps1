<#
.SYNOPSIS
    Verifie que le DWH est JOIGNABLE depuis les conteneurs Airflow (equivalent de check_dwh.sh).
    A lancer si un TP echoue avec : failed to resolve host 'postgres-dwh'
#>
$ErrorActionPreference = "Continue"
Set-Location (Join-Path $PSScriptRoot "..")

$engine = if (Get-Command podman -ErrorAction SilentlyContinue) { "podman" } else { "docker" }

Write-Host "=== 1. Le conteneur postgres-dwh tourne-t-il ? ===" -ForegroundColor Cyan
$dwh = (& $engine ps --format "{{.Names}}" | Select-String "postgres-dwh" | Select-Object -First 1)
if (-not $dwh) { Write-Host "[FAIL] postgres-dwh introuvable -> astro dev restart" -ForegroundColor Red; exit 1 }
Write-Host "[ OK ] $dwh" -ForegroundColor Green

$sched = (& $engine ps --format "{{.Names}}" | Select-String "scheduler" | Select-Object -First 1)

Write-Host "`n=== 2. Reseaux ===" -ForegroundColor Cyan
Write-Host "scheduler    : $(& $engine inspect $sched --format '{{range `$k,`$v := .NetworkSettings.Networks}}{{`$k}} {{end}}')"
Write-Host "postgres-dwh : $(& $engine inspect $dwh   --format '{{range `$k,`$v := .NetworkSettings.Networks}}{{`$k}} {{end}}')"
Write-Host "(les deux doivent partager au moins un reseau)"

Write-Host "`n=== 3. Resolution du nom depuis le scheduler ===" -ForegroundColor Cyan
& $engine exec $sched python -c "import socket;print(socket.gethostbyname('postgres-dwh'))" 2>$null
if ($LASTEXITCODE -eq 0) { Write-Host "[ OK ] 'postgres-dwh' est resolvable" -ForegroundColor Green }
else {
    Write-Host "[FAIL] nom non resolvable" -ForegroundColor Red
    Write-Host "       -> docker-compose.override.yml doit contenir  networks: [airflow]"
    Write-Host "       -> puis : astro dev restart"
    exit 1
}

Write-Host "`n=== 4. Connexion SQL ===" -ForegroundColor Cyan
& $engine exec $dwh psql -U snowy -d snowystore -c "SELECT 1;" *>$null
if ($LASTEXITCODE -eq 0) { Write-Host "[ OK ] la base snowystore repond" -ForegroundColor Green }
else { Write-Host "[FAIL] la base ne repond pas" -ForegroundColor Red; exit 1 }

Write-Host "`nTout est bon : les TP PostgreSQL peuvent se lancer." -ForegroundColor Green

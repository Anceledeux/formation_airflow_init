#!/usr/bin/env bash
# Prepare le depot Git de la formation : commit initial + tags de points de reprise.
# A executer UNE FOIS, depuis la racine du projet, avant de publier.
#
# Usage :
#   ./scripts/init_git.sh                                  # depot local seulement
#   ./scripts/init_git.sh https://github.com/vous/repo.git  # + push vers l'origine
set -e
cd "$(dirname "$0")/.."

REMOTE="${1:-}"

if [ -d .git ]; then
  echo "Un depot Git existe deja ici. Rien a faire."
  echo "Pour repartir de zero : rm -rf .git puis relancer ce script."
  exit 0
fi

echo "=== 1. Documents formateur ==="
FORMATEUR_FILES=""
for f in FORMATEUR.md DISTRIBUTION.md REPETITION_GENERALE.md MON_PROGRAMME_FORMATEUR.md \
         AIRFLOW_REFERENCE.md EMAIL_PREPARATION.md LUNDI_MATIN.md; do
  [ -f "$f" ] && FORMATEUR_FILES="$FORMATEUR_FILES $f"
done
if [ -n "$FORMATEUR_FILES" ]; then
  echo "  Ces fichiers sont destines au FORMATEUR :$FORMATEUR_FILES"
  read -r -p "  Les exclure du depot publie ? [O/n] " rep
  if [ "$rep" != "n" ] && [ "$rep" != "N" ]; then
    mkdir -p ../formateur-notes
    for f in $FORMATEUR_FILES; do mv "$f" ../formateur-notes/; done
    echo "  -> deplaces vers ../formateur-notes/"
  fi
fi

echo "=== 2. Depot et commit initial ==="
git init -b main >/dev/null
git add .
git commit -q -m "Projet de formation Apache Airflow 3 - Snowystore"
echo "  commit initial cree"

echo "=== 3. Points de reprise (tags) ==="
# Un tag par corrige : permet  git checkout tpXX-solution -- dags/
for f in solutions/*.py; do
  base=$(basename "$f" .py)      # ex : tp05_factorisation
  tp="${base%%_*}"               # ex : tp05
  tag="${tp}-solution"
  git tag -f "$tag" -m "Corrige $tp" >/dev/null 2>&1 || true
done
echo "  tags crees : $(git tag | tr '\n' ' ')"

if [ -n "$REMOTE" ]; then
  echo "=== 4. Publication ==="
  git remote add origin "$REMOTE"
  git push -u origin main
  git push --tags
  echo "  publie sur $REMOTE"
else
  echo "=== 4. Publication (a faire) ==="
  echo "  git remote add origin <url-du-depot>"
  echo "  git push -u origin main && git push --tags"
fi

cat <<'MSG'

------------------------------------------------------------------
DEPOT PRET.

A verifier avant de communiquer le lien aux stagiaires :
  - le depot ne contient PAS vos notes formateur
  - INSTALLATION.md et README.md sont bien presents
  - le lien est accessible sans compte (depot public), ou les
    stagiaires sont invites (depot prive)

Points de reprise cote stagiaire :
  ./scripts/reset_tp.sh tp05          (fonctionne aussi sans Git)
  git checkout tp05-solution -- dags/ (si depot Git)
------------------------------------------------------------------
MSG

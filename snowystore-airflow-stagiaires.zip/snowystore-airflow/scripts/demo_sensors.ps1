<#
.SYNOPSIS
    Pilote la demo des 3 modes de sensor (equivalent de demo_sensors.sh).
.EXAMPLE
    .\scripts\demo_sensors.ps1 reset    # supprime le fichier attendu (avant la demo)
    .\scripts\demo_sensors.ps1 go       # cree le fichier (debloque les 3 sensors)
#>
param([Parameter(Mandatory = $true, Position = 0)][ValidateSet("reset", "go")][string]$Action)

$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")
$f = "include\data\demo_sensors.txt"

if ($Action -eq "reset") {
    Remove-Item $f -ErrorAction SilentlyContinue
    Write-Host "Fichier supprime : les sensors vont attendre."
    Write-Host "-> installer le DAG :  Copy-Item solutions\demo_sensors_modes.py dags\"
    Write-Host "-> puis l'activer et le declencher dans l'interface."
} else {
    New-Item -ItemType Directory -Force -Path include\data | Out-Null
    New-Item -ItemType File -Force -Path $f | Out-Null
    Write-Host "Fichier cree : les 3 sensors se debloquent a leur prochaine verification (~15 s)."
}

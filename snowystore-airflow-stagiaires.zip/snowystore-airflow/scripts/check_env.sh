#!/usr/bin/env bash
# A EXECUTER PAR CHAQUE STAGIAIRE 3 JOURS AVANT LA FORMATION.
# Verifie que le poste est pret : evite de perdre la matinee du J1.
set -u
OK="[ OK ]"; KO="[FAIL]"; WARN="[WARN]"
fail=0

echo "=== Verification de l'environnement — Formation Apache Airflow ==="

# 0. Suis-je bien a la racine du projet Astro ?
if [ -f .astro/config.yaml ] && [ -f Dockerfile ]; then
  echo "$OK projet Astro detecte ($(pwd))"
else
  echo "$KO ce dossier n'est PAS la racine du projet Astro"
  echo "     -> 'ls -a' doit montrer .astro et Dockerfile"
  echo "     -> l'archive cree parfois un dossier imbrique : essayez 'cd snowystore-airflow'"
  fail=1
fi

# 1. Podman (recommande) ou Docker
ENGINE=""
if command -v podman >/dev/null 2>&1; then
  if podman info >/dev/null 2>&1; then echo "$OK podman installe et fonctionnel : $(podman --version)"; ENGINE=podman
  else echo "$KO podman installe mais ne repond pas — lancer : podman machine start"; fail=1; fi
elif command -v docker >/dev/null 2>&1; then
  if docker info >/dev/null 2>&1; then echo "$OK docker installe et demarre : $(docker --version)"; ENGINE=docker
  else echo "$KO docker installe mais le daemon ne repond pas (lancer Docker Desktop)"; fail=1; fi
else
  echo "$KO ni podman ni docker trouve — installer Podman (recommande) : voir INSTALLATION.md"; fail=1
fi

# 2. Astro CLI
if command -v astro >/dev/null 2>&1; then echo "$OK astro CLI : $(astro version 2>/dev/null | head -1)"
else echo "$KO astro CLI absent — https://www.astronomer.io/docs/astro/cli/install-cli"; fail=1; fi

# 1b. Une seule machine Podman active ?
if [ "$ENGINE" = "podman" ] && command -v podman >/dev/null 2>&1; then
  NB=$(podman machine list 2>/dev/null | grep -ci "currently running" || true)
  if [ "${NB:-0}" -gt 1 ]; then
    echo "$KO $NB machines Podman tournent en meme temps -> conflit de connexion"
    echo "     -> n'en garder qu'une : podman machine stop <autre-machine>"
    fail=1
  elif [ "${NB:-0}" -eq 1 ]; then
    echo "$OK une seule machine Podman active"
  fi
fi

# 2b. Astro configure sur le bon moteur
if command -v astro >/dev/null 2>&1; then
  BIN=$(astro config get -g container.binary 2>/dev/null | tr -d '\r' | tail -1)
  if [ -n "$ENGINE" ] && [ "$BIN" = "$ENGINE" ]; then echo "$OK astro configure sur '$BIN'"
  elif [ -n "$ENGINE" ]; then echo "$WARN astro pointe sur '${BIN:-docker}' mais vous utilisez '$ENGINE' -> astro config set -g container.binary $ENGINE"; fi
fi

# 3. Python >= 3.12
if command -v python3 >/dev/null 2>&1; then
  PYV=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
  if python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3,12) else 1)'; then
    echo "$OK python $PYV"
  else echo "$WARN python $PYV (>= 3.12 recommande pour les tests hors conteneur)"; fi
else echo "$WARN python3 absent (necessaire seulement hors conteneur)"; fi

# 4. Ports libres
for port in 8080 5432 5433; do
  if command -v lsof >/dev/null 2>&1 && lsof -i :"$port" >/dev/null 2>&1; then
    echo "$WARN port $port deja utilise — liberer avant 'astro dev start'"
  else echo "$OK port $port libre"; fi
done

# 5. RAM
if command -v free >/dev/null 2>&1; then
  RAM=$(free -g | awk '/^Mem:/{print $2}')
  if [ "$RAM" -ge 15 ]; then echo "$OK RAM ${RAM} Go"
  elif [ "$RAM" -ge 7 ]; then echo "$WARN RAM ${RAM} Go — suffisant mais juste (16 Go recommandes)"
  else echo "$KO RAM ${RAM} Go — insuffisant"; fail=1; fi
fi

# 6. Acces registre d'images
if [ -n "$ENGINE" ]; then
  echo "... test de telechargement d'image (peut prendre 30 s)"
  if $ENGINE pull hello-world >/dev/null 2>&1; then echo "$OK acces au registre d'images"
  else echo "$KO impossible de telecharger une image — proxy/firewall ? Voir INSTALLATION.md section 13"; fail=1; fi
fi

echo "================================================================"
if [ "$fail" -eq 0 ]; then echo "Poste PRET. A bientot en formation !"; else
  echo "Des points bloquants subsistent : les signaler AVANT la formation."; fi
exit $fail

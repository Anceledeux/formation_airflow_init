#!/usr/bin/env bash
# Recale toute la formation sur les dates de VOTRE session.
#
# Les corriges utilisent start_date=datetime(2026, 7, 20). Si votre session a lieu
# a une autre date, les TP lisant orders_{{ ds }}.csv echoueront (FileNotFoundError).
# Ce script met a jour les start_date ET regenere les donnees correspondantes.
#
# Usage :
#   ./scripts/set_start_date.sh 2026-09-14          # 1er jour de formation
#   ./scripts/set_start_date.sh 2026-09-14 --dry-run
set -e
cd "$(dirname "$0")/.."

DATE="${1:-}"
DRY="${2:-}"

if [ -z "$DATE" ]; then
  echo "Usage : ./scripts/set_start_date.sh AAAA-MM-JJ  (date du 1er jour de formation)"
  exit 1
fi
if ! date -d "$DATE" >/dev/null 2>&1; then
  echo "Date invalide : $DATE (format attendu : AAAA-MM-JJ)"
  exit 1
fi

# On demarre les DAGs 10 jours avant la formation : assez d'historique pour
# observer catchup et backfill, sans generer des centaines de runs.
START=$(date -d "$DATE -10 days" +%Y-%m-%d)
Y=$(date -d "$START" +%Y); M=$(date -d "$START" +%-m); D=$(date -d "$START" +%-d)

echo "Formation le      : $DATE"
echo "Nouvelle start_date : $START  ->  datetime($Y, $M, $D)"
echo

FILES=$(grep -rl "start_date=datetime(" dags solutions 2>/dev/null || true)
if [ -z "$FILES" ]; then echo "Aucun fichier a modifier."; exit 0; fi

for f in $FILES; do
  ACTUEL=$(grep -o "start_date=datetime([0-9]\{4\}, [0-9]\{1,2\}, [0-9]\{1,2\})" "$f" | head -1)
  echo "  $f : $ACTUEL -> start_date=datetime($Y, $M, $D)"
  if [ "$DRY" != "--dry-run" ]; then
    sed -i "s/start_date=datetime([0-9]\{4\}, [0-9]\{1,2\}, [0-9]\{1,2\})/start_date=datetime($Y, $M, $D)/g" "$f"
  fi
done

# ATTENTION : snowystore_broken.py utilise datetime.now() VOLONTAIREMENT (bug 3 du TP debug).
# Le grep ci-dessus ne le touche pas : c'est voulu, ne pas le "corriger".

if [ "$DRY" = "--dry-run" ]; then
  echo; echo "(simulation : aucun fichier modifie)"; exit 0
fi

echo
echo "=== Regeneration des donnees ==="
# Couvre du debut des DAGs jusqu'a la fin de la formation (3 jours) + marge
FIN=$(date -d "$DATE +4 days" +%Y-%m-%d)
python3 include/generate_orders.py --start "$START" --end "$FIN"

echo
echo "Termine. Verifications :"
echo "  ls include/data | head -3   &&   ls include/data | tail -3"
echo "  grep -r 'start_date=datetime' solutions | head -3"
echo
echo "Ne pas oublier : 'astro dev restart' si l'environnement tourne deja."

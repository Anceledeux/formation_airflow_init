"""TP2 bis — CORRIGE du DAG saboté.

Les 5 bugs et leur correction :
  1. DummyOperator      -> EmptyOperator (renomme en Airflow 3)
  2. context['date_du_jour'] -> context['ds'] (cle de contexte inexistante)
  3. start_date=datetime.now() -> date FIXE (sinon le DAG ne se declenche jamais :
     la date bouge a chaque relecture par le DAG Processor)
  4. catchup=True non maitrise -> catchup=False
  5. dependance circulaire (load >> extract) -> supprimee : un DAG est ACYCLIQUE

Le plus sournois est le n.3 : le DAG s'affiche, ne leve aucune erreur, et pourtant
ne se declenche jamais. C'est l'anti-pattern le plus courant en production.
"""
from __future__ import annotations

from datetime import datetime, timedelta

from airflow.sdk import DAG
from airflow.providers.standard.operators.bash import BashOperator
from airflow.providers.standard.operators.empty import EmptyOperator   # FIX 1
from airflow.providers.standard.operators.python import PythonOperator


def check_data(**context):
    print(f"Verification des donnees du {context['ds']}")               # FIX 2
    return True


with DAG(
    dag_id="snowystore_fixed",
    start_date=datetime(2026, 7, 20),                                   # FIX 3
    schedule="@daily",
    catchup=False,                                                      # FIX 4
    default_args={"owner": "formation", "retries": 1, "retry_delay": timedelta(minutes=1)},
    tags=["snowystore", "debug", "corrige"],
) as dag:

    extract = BashOperator(task_id="extract", bash_command="echo 'extraction du {{ ds }}'")
    check = PythonOperator(task_id="check", python_callable=check_data)
    load = EmptyOperator(task_id="load")

    extract >> check >> load                                            # FIX 5 : plus de cycle

"""TP1 bis — Le meme DAG, ecrit avec la TaskFlow API (@dag / @task).

A comparer avec tp01 : dependances et XComs deviennent implicites.
C'est cette version qui sert de base aux TP suivants.
"""
from __future__ import annotations

from datetime import datetime, timedelta

from airflow.sdk import dag, task

default_args = {"owner": "formation", "retries": 2, "retry_delay": timedelta(minutes=1)}


@dag(
    dag_id="snowystore_etl_taskflow",
    start_date=datetime(2026, 6, 1),
    schedule="@daily",
    catchup=False,
    default_args=default_args,
    tags=["snowystore", "tp1bis"],
)
def snowystore_etl_taskflow():

    @task
    def extract() -> int:
        """Renvoie un nombre de lignes : devient automatiquement un XCom."""
        n_rows = 1234
        print(f"Extraction : {n_rows} lignes")
        return n_rows

    @task
    def transform(n_rows: int) -> int:
        """Recoit le XCom en argument : la dependance est deduite de l'appel."""
        print(f"Transformation de {n_rows} lignes")
        return n_rows

    @task
    def load(n_rows: int) -> None:
        print(f"Chargement de {n_rows} lignes dans le DWH")

    # Les dependances se deduisent des appels : aucun >> a ecrire.
    load(transform(extract()))


snowystore_etl_taskflow()

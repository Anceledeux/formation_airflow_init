<#
.SYNOPSIS
    Recale toute la formation sur la date de VOTRE session (equivalent de set_start_date.sh).
.DESCRIPTION
    Les corriges utilisent une start_date fixe. Si la session a lieu a une autre date,
    les TP lisant orders_{{ ds }}.csv echoueront (FileNotFoundError).
    Ce script met a jour les start_date ET regenere les donnees correspondantes.
.EXAMPLE
    .\scripts\set_start_date.ps1 2026-09-14
    .\scripts\set_start_date.ps1 2026-09-14 -DryRun
#>
param(
    [Parameter(Mandatory = $true, Position = 0)][string]$Date,
    [switch]$DryRun
)

$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")

try { $d = [datetime]::ParseExact($Date, "yyyy-MM-dd", $null) }
catch { Write-Host "Date invalide : $Date (format attendu AAAA-MM-JJ)" -ForegroundColor Red; exit 1 }

# On demarre les DAGs 10 jours avant la formation : assez d'historique pour
# observer catchup et backfill, sans generer des centaines de runs.
$start = $d.AddDays(-10)
$fin   = $d.AddDays(4)

Write-Host "Formation le        : $($d.ToString('yyyy-MM-dd'))"
Write-Host "Nouvelle start_date : $($start.ToString('yyyy-MM-dd'))  ->  datetime($($start.Year), $($start.Month), $($start.Day))"
Write-Host ""

$motif       = 'start_date=datetime\(\d{4},\s*\d{1,2},\s*\d{1,2}\)'
$remplacement = "start_date=datetime($($start.Year), $($start.Month), $($start.Day))"

$fichiers = Get-ChildItem -Path dags, solutions -Filter *.py -ErrorAction SilentlyContinue |
            Where-Object { (Get-Content $_.FullName -Raw) -match $motif }

if (-not $fichiers) { Write-Host "Aucun fichier a modifier."; exit 0 }

foreach ($f in $fichiers) {
    $contenu = Get-Content $f.FullName -Raw
    $actuel  = [regex]::Match($contenu, $motif).Value
    Write-Host "  $($f.FullName -replace [regex]::Escape($PWD.Path + '\'), '') : $actuel -> $remplacement"
    if (-not $DryRun) {
        ($contenu -replace $motif, $remplacement) | Set-Content $f.FullName -NoNewline
    }
}

# ATTENTION : snowystore_broken.py utilise datetime.now() VOLONTAIREMENT
# (bug 3 du TP debug). Le motif ci-dessus ne le touche pas : c'est voulu.

if ($DryRun) { Write-Host "`n(simulation : aucun fichier modifie)" -ForegroundColor Yellow; exit 0 }

Write-Host "`n=== Regeneration des donnees ===" -ForegroundColor Cyan
python include/generate_orders.py --start $start.ToString("yyyy-MM-dd") --end $fin.ToString("yyyy-MM-dd")

Write-Host "`nTermine. Verifications :" -ForegroundColor Green
Write-Host "  dir include\data | Select-Object -First 3"
Write-Host "  Select-String -Path solutions\*.py -Pattern 'start_date=datetime' | Select-Object -First 3"
Write-Host "`nNe pas oublier : 'astro dev restart' si l'environnement tourne deja."

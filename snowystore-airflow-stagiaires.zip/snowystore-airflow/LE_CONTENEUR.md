# Le conteneur : pourquoi, quand et comment y entrer

Guide stagiaire. À lire au TP0, et à garder sous la main pendant les trois jours.

---

## 1. Deux mondes, deux terminaux

Quand vous lancez `astro dev start`, Airflow **ne s'installe pas sur votre machine**. Il démarre
dans des **conteneurs** : des environnements Linux isolés, avec leur propre Python, leurs propres
paquets, leur propre système de fichiers.

Vous travaillez donc dans deux mondes distincts :

| | Votre machine (l'hôte) | Le conteneur |
|---|---|---|
| Ce qu'on y trouve | Podman, l'Astro CLI, votre éditeur, Git | Airflow, Python 3.14, les providers |
| Commandes disponibles | `astro …`, `podman …`, `git`, `python` | `airflow …`, `pytest`, `python` (celui d'Airflow) |
| Où vous êtes le plus souvent | ici | ponctuellement |

**Comment savoir où je suis ?** Regardez l'invite de commande :

```
ancel@Laptop ~/Documents/Airflow/snowystore-airflow      <- votre machine
astro@0af70458fcee:/usr/local/airflow$                   <- DANS le conteneur
```

Dans le conteneur, le nom d'utilisateur est `astro`, la machine porte un identifiant illisible
(l'ID du conteneur), et le dossier est `/usr/local/airflow`.

> **La confusion classique :** taper `airflow dags list` sur votre machine et obtenir
> `bash: airflow: command not found`. C'est normal — **Airflow n'est pas installé chez vous**,
> il est dans le conteneur. Il faut y entrer d'abord.

---

## 2. Les dossiers sont partagés

Point essentiel, qui évite bien des malentendus : `dags/`, `include/`, `plugins/` et `tests/`
sont **montés** dans le conteneur. C'est le **même** dossier, vu des deux côtés.

```
Votre machine                          Conteneur
snowystore-airflow/dags/       <-->    /usr/local/airflow/dags/
snowystore-airflow/include/    <-->    /usr/local/airflow/include/
```

Conséquences pratiques :

- Vous **écrivez vos DAGs dans votre éditeur habituel**, sur votre machine. Aucun besoin
  d'entrer dans le conteneur pour coder.
- Un fichier enregistré est **immédiatement visible** par Airflow. Le DAG apparaît dans
  l'interface au bout de ~30 secondes, le temps que le DAG Processor le relise.
- Un fichier créé **dans** le conteneur hors de ces dossiers (par exemple dans `/tmp`)
  **disparaît** au redémarrage.

---

## 3. Quand faut-il entrer dans le conteneur ?

### ✅ Oui, il faut y entrer pour…

| Besoin | Commande (dans le conteneur) |
|--------|------------------------------|
| Utiliser la **CLI Airflow** | `airflow dags list`, `airflow tasks test …` |
| Voir le détail d'une **erreur d'import** | `airflow dags list-import-errors` |
| Forcer la prise en compte d'un DAG (dépannage) | `airflow dags reserialize` |
| Lancer les **tests** | `pytest tests/ -v` |
| Vérifier la **version** d'Airflow | `airflow version` |
| Tester un import Python | `python -c "from airflow.sdk import DAG"` |
| Rejouer une plage de dates | `airflow dags backfill …` |
| Créer un utilisateur (TP sécurité) | `airflow users create …` |

### ❌ Non, restez sur votre machine pour…

| Besoin | Commande (sur votre machine) |
|--------|------------------------------|
| Écrire et modifier vos DAGs | votre éditeur |
| Démarrer / arrêter / redémarrer | `astro dev start` · `stop` · `restart` |
| Consulter les logs | `astro dev logs -f` (filtrer : voir ci-dessous) |
| Générer les données du fil rouge | `python include/generate_orders.py --days 20` |
| Git | `git status`, `git commit` |
| Gérer Podman | `podman ps`, `podman machine list` |

**Règle simple :** tout ce qui commence par `airflow` se fait **dans** le conteneur, tout ce qui
commence par `astro`, `podman` ou `git` se fait **sur votre machine**.

---

## 4. Comment entrer et sortir

### Entrer

```bash
astro dev bash
```

Sous **Git Bash** sur Windows, la commande a besoin d'un terminal interactif :

```bash
winpty astro dev bash
```

Vous arrivez par défaut dans le conteneur du **scheduler**, qui contient tout ce dont vous avez
besoin. (Les autres composants — API server, triggerer, dag-processor — sont dans des conteneurs
séparés ; `astro dev bash --help` liste les options si vous devez viser l'un d'eux.)

### Sortir

```bash
exit
```

ou **Ctrl + D**.

> **Sortir du conteneur n'arrête PAS Airflow.** Vous quittez seulement votre session de terminal ;
> les conteneurs continuent de tourner. Pour arrêter Airflow, c'est `astro dev stop`, depuis
> votre machine.

### Lancer une commande sans entrer

Pratique pour une commande unique :

```bash
podman exec -it <nom-du-conteneur-scheduler> airflow dags list
```

Le nom exact s'obtient avec `podman ps` (il ressemble à `snowystore-airflow_xxxxx-scheduler-1`).

---

## 4 bis. Arrêter Airflow quand on ne s'en sert pas

Trois niveaux, selon ce que vous voulez libérer.

### Arrêt normal — le geste quotidien

```bash
astro dev stop
```

Les conteneurs s'arrêtent, **tout est conservé** : historique des runs, états des DAGs,
connexions. Le prochain `astro dev start` prend 30 à 60 secondes.

### Libérer aussi la mémoire

Point souvent oublié : `astro dev stop` arrête les conteneurs, mais la **machine virtuelle
Podman continue de tourner** et garde sa RAM réservée (4 à 8 Go). Sur un poste de 16 Go, ça
se sent.

```bash
astro dev stop
podman machine stop astro-machine
wsl --shutdown                      # Windows : rend toute la mémoire au système
```

### Repartir de zéro

```bash
astro dev kill
```

Détruit conteneurs **et volumes** : vous perdez l'historique des runs et la base de
métadonnées. En revanche :

- vos fichiers dans `dags/` et `include/` sont **intacts** ;
- les connexions, variables et pools sont **reprovisionnés automatiquement** depuis
  `airflow_settings.yaml` au démarrage suivant.

C'est donc sans risque — juste plus long à redémarrer. À utiliser entre deux sessions, ou
quand quelque chose est cassé sans qu'on sache pourquoi.

| Commande | Conteneurs | Données (runs, historique) | RAM de la VM |
|----------|-----------|---------------------------|--------------|
| `astro dev stop` | arrêtés | conservées | **toujours réservée** |
| + `podman machine stop` | arrêtés | conservées | libérée |
| `astro dev kill` | supprimés | **perdues** | toujours réservée |

## 4 ter. Lire les logs sans se noyer

`astro dev logs --scheduler -f` produit un flux très verbeux, majoritairement du bruit.
Pour ne garder que l'essentiel :

```bash
astro dev logs --scheduler -f | grep -E "up for execution|queued state|TaskInstance Finished|DagRun Finished"
```
```powershell
# PowerShell : grep n'existe pas, l'equivalent est Select-String
astro dev logs --scheduler -f | Select-String "up for execution|queued state|TaskInstance Finished|DagRun Finished"
```

> **Filtrer selon le terminal :** `grep` (Git Bash, macOS, Linux) · `Select-String`
> (PowerShell). Un `grep` dans PowerShell renvoie *le terme « grep » n'est pas reconnu*.
>
> **Dans 95 % des cas, ce ne sont pas ces logs qu'il vous faut.** Pour savoir ce que fait une
> tâche ou pourquoi elle échoue, ouvrez les **logs de la tâche** dans l'interface : cliquez sur
> la tâche dans la vue Grid, onglet Logs. C'est le geste à prendre.
>
> Les logs du scheduler ne servent qu'à diagnostiquer un problème de **planification** :
> une tâche qui ne démarre jamais, ou qui reste bloquée en file.

## 4 quater. « Tous mes DAGs se lancent au démarrage »

**Cause :** l'état activé / en pause d'un DAG vit dans la **base de métadonnées**, pas dans le
code. Un DAG que vous avez activé pour tester **reste activé** après `astro dev stop`. Au
redémarrage, le scheduler constate que le dernier intervalle est clos et lance aussitôt un run.

**Trois solutions :**

```bash
# 1. Mettre en pause avant d'arrêter (le plus propre)
./scripts/pause_all.sh
astro dev stop

# 2. Repartir d'une base vide (radical, entre deux sessions)
astro dev kill && astro dev start

# 3. Voir l'état actuel
./scripts/pause_all.sh --list
```

`astro dev kill` efface la base de métadonnées : tous les DAGs redeviennent en pause, qui est
l'état par défaut à la création. Vos fichiers dans `dags/` et `include/` sont intacts, et les
connexions, variables et pools sont reprovisionnés automatiquement.

> Pour un DAG de laboratoire que vous ne voulez **jamais** voir se déclencher seul :
> `schedule=None`. Il ne partira alors que sur déclenchement manuel.

## 5. Deux pièges à connaître

### Ce que vous installez dans le conteneur est perdu

```bash
pip install pandas     # DANS le conteneur -> disparaît au prochain restart
```

Les conteneurs sont **jetables** : ils repartent de l'image à chaque redémarrage. Pour ajouter
durablement un paquet, il faut le déclarer dans `requirements.txt` **sur votre machine**, puis
reconstruire l'image :

```bash
astro dev restart      # PAS stop + start : il faut reconstruire
```

C'est l'erreur la plus courante : « j'ai ajouté un provider mais il n'apparaît pas ».

### Le Python du conteneur n'est pas le vôtre

Votre éditeur soulignera peut-être en rouge `from airflow.sdk import dag, task` : c'est normal,
Airflow n'est pas installé sur votre machine. **Le code fonctionne** — il s'exécute dans le
conteneur. Voir `INSTALLATION.md § 8.4` si vous voulez l'autocomplétion (optionnel).

---

## 6. Mémo des commandes utiles dans le conteneur

```bash
# Diagnostic
airflow version
airflow dags list                      # les DAGs enregistrés
airflow dags list-import-errors        # LE réflexe si un DAG n'apparaît pas
airflow dags reserialize               # forcer la prise en compte du dossier dags/
airflow tasks list <dag_id>

# Développement
airflow tasks test <dag_id> <task_id> <date>   # une tâche, isolément
airflow dags test <dag_id> <date>              # le DAG entier, en local
airflow dags backfill -s <début> -e <fin> <dag_id>

# Tests
pytest tests/ -v

# Base de données de métadonnées
airflow db clean --clean-before-timestamp <date>

# Interroger le DWH DEPUIS Airflow (psql n'est PAS installé dans ce conteneur :
# l'image embarque psycopg, la bibliothèque Python, pas le client en ligne de commande)
python -c "
from airflow.providers.postgres.hooks.postgres import PostgresHook
h = PostgresHook(postgres_conn_id='snowystore_dwh')
for r in h.get_records('SELECT * FROM mart_daily_sales LIMIT 10'): print(r)
"
```

> Interroger le DWH par le hook a un avantage : cela **prouve au passage que la connexion
> Airflow fonctionne**. Depuis votre machine, le raccourci `./scripts/dwh.sh` est plus court.

---

## 7. « Mon DAG n'apparaît pas » — la marche à suivre

> **En temps normal, vous n'avez rien à faire :** le DAG Processor relit `dags/` toutes les
> ~30 secondes et enregistre vos DAGs automatiquement. Les commandes ci-dessous sont des
> **réflexes de dépannage**, pas une étape obligatoire après chaque création de DAG.

1. Attendre **30 secondes** : le DAG Processor relit le dossier périodiquement.
   *Le tout premier chargement, juste après `astro dev start`, est plus lent (démarrage à
   froid) : laissez-lui jusqu'à 1 à 2 minutes.*
2. Regarder le bandeau **« Erreur d'importation de Dag »** en haut de la page des DAGs.
3. Dans le conteneur :

```bash
airflow dags list-import-errors     # le message d'erreur exact, avec le numéro de ligne
airflow dags reserialize            # forcer la relecture
airflow dags list                   # le DAG est-il enregistré ?
```

4. Vérifier que le fichier se charge sans erreur :

```bash
python /usr/local/airflow/dags/mon_dag.py    # ne doit RIEN afficher
```

5. En dernier recours, depuis votre machine : `astro dev restart`.

### Le DAG apparaît, et ensuite ?

Le voir dans la liste prouve seulement qu'il **s'importe**. Pour vérifier qu'il **s'exécute** :

1. **Activer l'interrupteur** à gauche de son nom — un DAG est **en pause par défaut**.
   Avec `catchup=False` et une `start_date` passée, un run démarre alors automatiquement.
2. Ou utiliser le bouton **« Déclencher »** pour un run manuel immédiat.
3. Suivre les tâches passer au vert dans la vue **Grid**, puis **ouvrir les logs** d'une tâche.

Ouvrir les logs est le geste que vous répéterez le plus souvent pendant ces trois jours.

> ### ⚠️ Piège classique : les tâches restent « en file » et ne démarrent jamais
>
> **Cause :** le DAG est **en pause**. Un DAG en pause ne voit aucune de ses tâches programmée
> par le scheduler — *même si vous déclenchez un run manuellement*. Le run se crée, les tâches
> s'affichent... et attendent indéfiniment, sans aucun message d'erreur.
>
> **Solution :** activer l'interrupteur à gauche du nom du DAG, ou cocher
> **« Réactiver <dag> lors du déclenchement »** dans la fenêtre de déclenchement.
>
> Retenez le symptôme : *tâches éternellement en attente + aucune erreur* = **DAG en pause**,
> neuf fois sur dix.

> Rappel : `snowystore_broken.py` est **volontairement cassé** (support du TP debug du Jour 1).
> L'erreur d'import à son sujet est normale et n'empêche pas les autres DAGs de fonctionner.

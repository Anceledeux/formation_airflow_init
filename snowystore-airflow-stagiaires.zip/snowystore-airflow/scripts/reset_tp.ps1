<#
.SYNOPSIS
    Point de reprise : installe le corrige d'un TP dans dags\ (equivalent PowerShell de reset_tp.sh).
.EXAMPLE
    .\scripts\reset_tp.ps1 -List
    .\scripts\reset_tp.ps1 tp05
#>
param(
    [Parameter(Position = 0)][string]$TP,
    [switch]$List
)

$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")

if ($List -or [string]::IsNullOrWhiteSpace($TP)) {
    Write-Host "Points de reprise disponibles :" -ForegroundColor Cyan
    Get-ChildItem solutions\*.py | ForEach-Object {
        $base = $_.BaseName
        $tp = $base.Split('_')[0]
        "  {0,-10} -> {1}" -f $tp, $base
    } | Sort-Object -Unique | Write-Host
    Write-Host ""
    Write-Host "Usage : .\scripts\reset_tp.ps1 tp05"
    exit 0
}

$found = Get-ChildItem "solutions\$TP*.py" -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $found) {
    Write-Host "Aucun corrige pour '$TP'. Lancer : .\scripts\reset_tp.ps1 -List" -ForegroundColor Red
    exit 1
}

New-Item -ItemType Directory -Force -Path "dags\_backup" | Out-Null
Get-ChildItem dags\*.py -ErrorAction SilentlyContinue |
    Copy-Item -Destination "dags\_backup" -Force -ErrorAction SilentlyContinue

Copy-Item $found.FullName -Destination "dags\" -Force

Write-Host "Corrige installe : $($found.Name) -> dags\" -ForegroundColor Green
Write-Host "(Votre travail precedent a ete sauvegarde dans dags\_backup\)"
Write-Host "Le DAG apparaitra dans l'UI sous 30 s."

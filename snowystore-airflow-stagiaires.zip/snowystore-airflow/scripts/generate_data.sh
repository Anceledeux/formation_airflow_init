#!/usr/bin/env bash
# Genere les CSV de commandes du fil rouge (a lancer avant le J1, et si besoin en cours de route).
set -e
cd "$(dirname "$0")/.."
python3 include/generate_orders.py --days "${1:-15}"
echo
echo "Astuce : pour le TP qualite de donnees, ajouter --anomalies"

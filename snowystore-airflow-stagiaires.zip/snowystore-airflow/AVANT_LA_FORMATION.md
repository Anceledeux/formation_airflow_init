# Avant la formation — préparez votre poste

**Formation Apache Airflow 3 — 3 jours**

Cette formation est un **stage pratique** : vous coderez sur votre propre machine dès la
première matinée. Pour ne pas perdre de temps le premier jour, merci d'installer les outils
**cette semaine**.

**Temps nécessaire : environ 45 minutes**, dont une bonne partie en téléchargements — vous
pouvez faire autre chose pendant.

> Le **projet de formation** vous sera remis le premier jour. Ici, vous installez seulement les
> outils, et vous les validez sur un petit projet de test que vous supprimerez ensuite.

---

## ⚠️ À traiter en priorité — dès aujourd'hui

Deux points demandent parfois l'intervention de votre DSI, et **ne peuvent pas être réglés le
jour de la formation** :

1. **Droits administrateur** sur votre poste, nécessaires pour installer les outils.
2. **Accès aux registres d'images** : les domaines `astrocrpublic.azurecr.io` et `docker.io`
   doivent être joignables. Ils sont souvent bloqués par les proxys d'entreprise.

Si vous pensez être concerné, faites la demande **maintenant** : ces déblocages prennent
généralement plusieurs jours.

---

## Ce qu'il vous faut

| | |
|---|---|
| **Podman** | moteur de conteneurs — libre, sans contrainte de licence |
| **Astro CLI** | l'outil qui démarre Airflow en une commande |
| **Python 3.12+** | utilisé pendant les exercices |
| **Un IDE** | VS Code, PyCharm, ou celui de votre choix |

**Côté matériel :** 8 Go de RAM minimum (16 Go confortable), 10 Go de disque libre.
Les ports **8080**, **5432** et **5433** doivent être libres.

> **Bonne nouvelle :** sur Windows et macOS, l'Astro CLI installe **et configure Podman** tout
> seul. Une seule commande pour les deux.

---

## Étape 1 — Installer les outils

### Windows

Dans **PowerShell en tant qu'administrateur** :

```powershell
# 1. Activer WSL 2, puis REDÉMARRER la machine
wsl --install

# 2. Après redémarrage : installer l'Astro CLI (Podman est inclus)
winget install -e --id Astronomer.Astro

# 3. Installer Python
winget install -e --id Python.Python.3.12
```

**Fermez puis rouvrez PowerShell** — sinon les commandes ne seront pas reconnues.

### macOS

```bash
brew install astro                        # installe aussi Podman
podman machine init && podman machine start
brew install python@3.12
```

### Linux

```bash
sudo apt install -y podman python3.12     # ou dnf selon la distribution
systemctl --user enable --now podman.socket
curl -sSL install.astronomer.io | sudo bash -s
```

### Vérifiez

```bash
podman --version
astro version
python --version        # python3 --version sur macOS/Linux
```

Les trois doivent répondre. Si `astro` n'est pas reconnu, rouvrez votre terminal.

---

## Étape 2 — Brancher l'Astro CLI sur Podman

**C'est l'étape que tout le monde oublie.** Par défaut, l'Astro CLI cherche Docker :

```bash
astro config set -g container.binary podman
astro config get -g container.binary       # doit afficher : podman
```

Sans elle, le démarrage échouera avec un message incompréhensible.

---

## Étape 3 — Valider sur un projet de test

Ce projet est **jetable** : il sert uniquement à vérifier que la chaîne complète fonctionne, et
à télécharger l'image Airflow dès maintenant.

```bash
mkdir test-airflow
cd test-airflow
astro dev init          # <- la commande COMPLÈTE : c'est elle qui crée les fichiers
```

**Vérifiez immédiatement que les fichiers ont bien été créés :**

```bash
ls          # macOS, Linux, Git Bash
dir         # Windows PowerShell
```

Vous devez voir apparaître, entre autres : **`Dockerfile`**, `requirements.txt`, et les dossiers
`dags/`, `include/`, `tests/`.

> **Si vous ne voyez rien**, c'est que la commande n'a pas été exécutée en entier. Taper `astro`
> seul affiche seulement l'aide, sans rien créer. La commande est bien **`astro dev init`**, en
> trois mots.

### Important : fixer la même version que la formation

Le fichier **`Dockerfile`** se trouve **à la racine** du dossier `test-airflow`, à côté de
`requirements.txt`. C'est un fichier **sans extension** — il s'appelle exactement `Dockerfile`.

Ouvrez-le dans votre éditeur, et remplacez son contenu par cette seule ligne :

```dockerfile
FROM astrocrpublic.azurecr.io/runtime:3.3
```

C'est la version que nous utiliserons. En la fixant maintenant, **l'image sera déjà téléchargée
le premier jour** — c'est le principal gain de temps de cette préparation.

### Si `astro dev init` échoue

Message typique :

```
Error: error getting default image tag: ... lookup updates.astronomer.io: no such host
```

**Cause :** la commande interroge `updates.astronomer.io` pour choisir la version par défaut de
l'image. Ce domaine est bloqué ou non résolu par votre réseau.

**Ce n'est pas bloquant** : nous fixons la version nous-mêmes juste après, donc cette
consultation ne nous sert à rien. Deux solutions.

**Solution 1 — utiliser le projet de test prêt à l'emploi.** Je vous ai envoyé
`test-airflow.zip` : décompressez-le, et passez directement à l'étape « Démarrez ». Tout y est
déjà (Dockerfile, `.astro/`, DAG d'exemple).

**Solution 2 — créer les fichiers à la main.** Dans un dossier `test-airflow` vide :

```bash
mkdir -p dags .astro
printf 'FROM astrocrpublic.azurecr.io/runtime:3.3
' > Dockerfile
printf 'project:
  name: test-airflow
' > .astro/config.yaml
touch requirements.txt packages.txt
```

Puis ajoutez le DAG d'exemple ci-dessous dans `dags/`.

> **Le test qui compte vraiment**, et que je vous demande de faire dans tous les cas :
>
> ```bash
> podman pull astrocrpublic.azurecr.io/runtime:3.3
> ```
>
> Si **cette** commande fonctionne, tout ira bien lundi. Si elle échoue, c'est le registre
> d'images qui est bloqué — **prévenez-moi immédiatement**, c'est le seul point qui nécessite
> une intervention de votre DSI.

### Ajoutez un DAG d'exemple

Créez le fichier `dags/test_installation.py` avec ce contenu :

```python
from datetime import datetime

from airflow.sdk import dag, task


@dag(
    dag_id="test_installation",
    start_date=datetime(2026, 1, 1),
    schedule=None,          # ne se déclenche que manuellement
    catchup=False,
    tags=["test"],
)
def test_installation():

    @task
    def bonjour() -> str:
        print("Installation reussie — a lundi !")
        return "ok"

    @task
    def au_revoir(message: str) -> None:
        print(f"La tache precedente a renvoye : {message}")

    au_revoir(bonjour())


test_installation()
```

### Démarrez

```bash
astro dev start
```

**Le premier démarrage télécharge plusieurs gigaoctets : comptez 5 à 15 minutes.** C'est normal,
et c'est précisément ce qu'on veut éviter de faire à plusieurs simultanément le premier jour.

Quand c'est prêt, ouvrez **http://localhost:8080** — identifiants `admin` / `admin`.

---

## Étape 4 — Vérifiez que tout fonctionne

Cochez ces cinq points :

- [ ] L'interface s'ouvre sur `http://localhost:8080` et la connexion fonctionne
- [ ] Le DAG **`test_installation`** apparaît dans la liste (comptez jusqu'à 1 minute)
- [ ] Vous **activez l'interrupteur** à gauche de son nom, puis vous le **déclenchez**
- [ ] Les deux tâches passent au **vert**
- [ ] En cliquant sur une tâche puis sur ses **logs**, vous lisez le message affiché

> **Note :** un DAG est **en pause** par défaut. Si vous le déclenchez sans activer
> l'interrupteur, les tâches resteront en attente sans jamais démarrer — et sans message
> d'erreur. C'est déroutant, c'est normal, et nous en reparlerons le premier jour.

### Vérifiez aussi la version

```bash
astro dev bash
airflow version        # doit afficher 3.3.x
exit
```

Sous **Git Bash** sur Windows, utilisez `winpty astro dev bash`.

---

## Étape 5 — Arrêter proprement

```bash
astro dev stop                       # arrête les conteneurs
podman machine stop                  # libère la mémoire (Windows/macOS)
```

Vous pouvez **conserver ou supprimer** le dossier `test-airflow` : il ne servira plus. L'image
téléchargée, elle, reste en cache — c'est tout l'intérêt.

---

## En cas de blocage

**Ne restez pas dessus.** Envoyez-moi un message avec :

- votre système (Windows / macOS / Linux),
- la commande lancée,
- le message d'erreur complet (copier-coller, ou capture d'écran).

### Les trois blocages les plus fréquents

| Message | Cause | Solution |
|---------|-------|----------|
| `astro: command not found` | terminal non rouvert | fermez et rouvrez votre terminal |
| `cannot connect to Podman` | machine virtuelle arrêtée | `podman machine start` |
| `error pulling image` / délai dépassé | proxy d'entreprise | à faire débloquer par la DSI — voir la section prioritaire en haut |

Un poste non préparé n'est pas insurmontable : nous prévoyons du temps de dépannage le premier
matin, et le travail en binôme reste possible. Mais chaque blocage réglé cette semaine est du
temps gagné pour la pratique.

**À lundi !**

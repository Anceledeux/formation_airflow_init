#!/usr/bin/env bash
# Raccourci pour interroger le DWH Snowystore (TP10 et suivants).
#
# Usage :
#   ./scripts/dwh.sh                             # ouvre une session psql interactive
#   ./scripts/dwh.sh "SELECT * FROM mart_daily_sales LIMIT 5;"
#   ./scripts/dwh.sh --mart                      # raccourci : contenu du mart
#   ./scripts/dwh.sh --check                     # test d'idempotence : compte les lignes
set -u
ENGINE=$(command -v podman >/dev/null 2>&1 && echo podman || echo docker)
CID=$($ENGINE ps -qf name=postgres-dwh | head -1)

if [ -z "$CID" ]; then
  echo "Conteneur postgres-dwh introuvable. Lancer : astro dev start"
  exit 1
fi

case "${1:-}" in
  "")
    # session interactive (winpty est gere par l'appelant sous Git Bash)
    exec $ENGINE exec -it "$CID" psql -U snowy -d snowystore
    ;;
  --mart)
    SQL="SELECT sale_date, category, total_amount FROM mart_daily_sales ORDER BY sale_date DESC, total_amount DESC LIMIT 20;"
    ;;
  --check)
    SQL="SELECT sale_date, COUNT(*) AS nb_categories, SUM(total_amount) AS total
         FROM mart_daily_sales GROUP BY sale_date ORDER BY sale_date DESC LIMIT 10;"
    echo "Test d'idempotence : relancez le MEME run, puis rejouez cette commande."
    echo "Les valeurs doivent etre IDENTIQUES, pas doublees."
    echo
    ;;
  --staging)
    SQL="SELECT load_date, COUNT(*) AS nb_lignes FROM staging_orders GROUP BY load_date ORDER BY load_date DESC LIMIT 10;"
    ;;
  *)
    SQL="$1"
    ;;
esac

$ENGINE exec "$CID" psql -U snowy -d snowystore -c "$SQL"

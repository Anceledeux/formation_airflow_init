"""TP2 — Scheduling : intervalles de donnees, catchup, backfill.

Points cles :
  - start_date FIXE (jamais datetime.now())
  - catchup=False par defaut
  - le run le plus recent porte la date de l'intervalle traite (souvent "hier")
"""
from __future__ import annotations

from datetime import datetime, timedelta

from airflow.sdk import dag, task

@dag(
    dag_id="snowystore_scheduling",
    start_date=datetime(2026, 7, 20),   # date FIXE
    schedule="@daily",                   # en Airflow 3 : "schedule", plus "schedule_interval"
    catchup=False,                       # passer a True pour observer le rattrapage
    default_args={"owner": "formation", "retries": 1, "retry_delay": timedelta(minutes=1)},
    tags=["snowystore", "tp2"],
)
def snowystore_scheduling():

    @task
    def show_interval(**context):
        """Affiche les bornes de l'intervalle de donnees traite par ce run."""
        print("logical_date       :", context["logical_date"])
        print("data_interval_start:", context["data_interval_start"])
        print("data_interval_end  :", context["data_interval_end"])
        print("ds (date du run)   :", context["ds"])
        return str(context["ds"])

    @task
    def process(ds_value: str):
        print(f"Traitement des commandes du {ds_value}")

    @task(trigger_rule="all_done")
    def notify():
        """Part meme si une tache amont a echoue (bonus du TP)."""
        print("Notification de fin de run")

    interval = show_interval()
    process(interval) >> notify()


snowystore_scheduling()

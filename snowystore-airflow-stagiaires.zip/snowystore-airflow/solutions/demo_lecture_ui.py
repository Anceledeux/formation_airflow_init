"""DEMO — apprendre a lire un run dans l'interface Airflow.

A utiliser pour le tout premier micro-exercice du Jour 1, AVANT le TP1.
Volontairement independant du fil rouge Snowystore : il ne devoile aucun
corrige, et son seul but est de donner quelque chose a OBSERVER.

MISE EN PLACE
-------------
    cp solutions/demo_lecture_ui.py dags/          (Bash)
    Copy-Item solutions\\demo_lecture_ui.py dags\\   (PowerShell)

Puis, dans l'interface : ACTIVER l'interrupteur, PUIS declencher.

CE QU'IL PERMET D'OBSERVER
--------------------------
  * vue Grid   : 5 taches, dont 2 en PARALLELE (couleurs et progression)
  * vue Graph  : la forme du graphe et le sens des dependances
  * Logs       : chaque tache ecrit un message explicite
  * Duree      : les taches n'ont pas la meme duree -> visible dans le Gantt
  * XCom       : "preparer" renvoie une valeur, visible dans l'onglet XCom
  * Retries    : "controle_qualite" ECHOUE au 1er essai et reussit au 2e
                 -> permet de montrer le numero de tentative dans les logs

Le DAG finit donc TOUJOURS en succes, malgre un echec visible en chemin :
c'est exactement ce qu'on veut montrer pour apprendre a lire un run.
"""
from __future__ import annotations

import time
from datetime import datetime, timedelta

from airflow.sdk import dag, task
from airflow.providers.standard.operators.empty import EmptyOperator


@dag(
    dag_id="demo_lecture_ui",
    start_date=datetime(2026, 1, 1),
    schedule=None,                 # declenchement manuel uniquement
    catchup=False,
    tags=["demo", "jour1"],
    default_args={"retries": 1, "retry_delay": timedelta(seconds=10)},
    doc_md=__doc__,                # s'affiche dans l'onglet "Docs" du DAG
)
def demo_lecture_ui():

    debut = EmptyOperator(task_id="debut")

    @task
    def preparer() -> int:
        """Simule une preparation et RENVOIE une valeur (visible en XCom)."""
        print("Preparation des donnees en cours...")
        time.sleep(3)
        nb_lignes = 1_284
        print(f"Preparation terminee : {nb_lignes} lignes pretes.")
        return nb_lignes

    @task
    def enrichir(nb_lignes: int) -> int:
        """Tache la plus longue : bien visible dans le Gantt."""
        print(f"Enrichissement de {nb_lignes} lignes...")
        time.sleep(8)
        print("Enrichissement termine.")
        return nb_lignes

    @task
    def controle_qualite(nb_lignes: int, **context) -> None:
        """ECHOUE au premier essai, reussit au second (retries=1).

        Objectif pedagogique : montrer le numero de tentative dans les logs,
        et le fait qu'un echec rattrape n'empeche pas le run de reussir.
        """
        tentative = context["task_instance"].try_number
        print(f"Controle qualite — tentative n°{tentative}")
        if tentative == 1:
            print("Service de controle indisponible : on retentera dans 10 s.")
            raise RuntimeError("Service de controle temporairement indisponible")
        print(f"Controle OK sur {nb_lignes} lignes.")

    @task
    def publier(nb_lignes: int) -> None:
        print(f"Publication de {nb_lignes} lignes. Termine.")

    lignes = preparer()
    debut >> lignes

    # enrichir et controle_qualite partent EN PARALLELE apres preparer :
    # c'est ce qui rend la vue Graph interessante a lire.
    enrichies = enrichir(lignes)
    qualite = controle_qualite(lignes)

    fin = publier(enrichies)
    qualite >> fin


demo_lecture_ui()

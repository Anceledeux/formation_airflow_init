"""TP9 — Asset Approach : la chaine complete pilotee par la donnee.

orders_raw --> sales_mart --> reporting
Un seul declenchement en tete propage toute la chaine, sans aucun horaire ni sensor.
"""
from __future__ import annotations

from datetime import datetime

from airflow.sdk import Asset, dag, task

orders_raw = Asset("snowystore://orders_raw")
sales_mart = Asset("snowystore://sales_mart")
reporting = Asset("snowystore://reporting")


@dag(dag_id="tp9_ingestion", start_date=datetime(2026, 7, 20), schedule="@daily",
     catchup=False, tags=["snowystore", "tp9"])
def tp9_ingestion():
    @task(outlets=[orders_raw])
    def ingest():
        print("Ingestion des commandes brutes -> orders_raw")
    ingest()


@dag(dag_id="tp9_transformation", start_date=datetime(2026, 7, 20), schedule=[orders_raw],
     catchup=False, tags=["snowystore", "tp9"])
def tp9_transformation():
    @task(outlets=[sales_mart])
    def build_mart():
        print("Construction du mart -> sales_mart")
    build_mart()


@dag(dag_id="tp9_reporting", start_date=datetime(2026, 7, 20), schedule=[sales_mart],
     catchup=False, tags=["snowystore", "tp9"])
def tp9_reporting():
    @task(outlets=[reporting])
    def build_report():
        print("Reporting genere -> reporting")
    build_report()


tp9_ingestion()
tp9_transformation()
tp9_reporting()

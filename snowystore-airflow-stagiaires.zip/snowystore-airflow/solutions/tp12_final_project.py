"""TP12 — Projet final : le pipeline Snowystore consolide, pret pour la production.

Assemble toutes les briques de la formation :
  sensor -> extract -> validate (branch) -> TaskGroup transform (.expand) ->
  load Postgres idempotent (pool) -> Asset -> notify
  + alerting, config externalisee, couvert par les tests.
"""
from __future__ import annotations

import csv
import json
from datetime import datetime, timedelta
from pathlib import Path

from airflow.sdk import Asset, Variable, dag, task, task_group
from airflow.providers.common.sql.operators.sql import SQLExecuteQueryOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.providers.standard.sensors.filesystem import FileSensor

from include.transform_logic import aggregate_by_category, clean_orders

DATA_DIR = Path("/usr/local/airflow/include/data")
CONN_ID = "snowystore_dwh"
sales_mart = Asset("snowystore://sales_mart")


def alert_on_failure(context):
    ti = context["task_instance"]
    config = json.loads(Variable.get("snowystore_config", default='{"alert_channel":"#local"}'))
    print(
        "ALERTE %s | dag=%s task=%s run=%s"
        % (config.get("alert_channel", "#local"), ti.dag_id, ti.task_id, context["run_id"])
    )


@dag(
    dag_id="snowystore_final",
    start_date=datetime(2026, 7, 20),
    schedule="@daily",
    catchup=False,
    max_active_runs=1,                       # evite que deux runs ecrivent la meme table
    dagrun_timeout=timedelta(hours=1),       # garde-fou sur la duree totale
    default_args={
        "owner": "formation",
        "retries": 2,
        "retry_delay": timedelta(seconds=30),
        "on_failure_callback": alert_on_failure,
    },
    tags=["snowystore", "tp12", "final"],
)
def snowystore_final():

    # NB : le FileSensor passe par un FSHook, qui a besoin d'une connexion de type "fs"
    # nommee "fs_default". Elle n'existe PAS par defaut en Airflow 3 : elle est
    # provisionnee dans airflow_settings.yaml du projet.
    # Sans elle : AirflowNotFoundException: The conn_id `fs_default` isn't defined
    wait_for_file = FileSensor(
        task_id="wait_for_orders",
        filepath="/usr/local/airflow/include/data/orders_{{ ds }}.csv",
        mode="reschedule",
        poke_interval=15,
        timeout=60 * 5,
    )

    create_tables = SQLExecuteQueryOperator(
        task_id="create_tables",
        conn_id=CONN_ID,
        sql="""
        CREATE TABLE IF NOT EXISTS mart_daily_sales (
            sale_date DATE, category TEXT, total_amount NUMERIC(14,2),
            PRIMARY KEY (sale_date, category)
        );
        """,
    )

    @task
    def extract(**context) -> list[dict]:
        path = DATA_DIR / f"orders_{context['ds']}.csv"
        with path.open(encoding="utf-8") as fh:
            rows = clean_orders(list(csv.DictReader(fh)))
        print(f"{len(rows)} lignes valides extraites")
        return rows

    @task.branch
    def validate(rows: list[dict]) -> str:
        """Aiguillage : si le volume est anormalement bas, on part en alerte."""
        return "transformations.transform_categories" if len(rows) >= 100 else "abort_low_volume"

    abort = EmptyOperator(task_id="abort_low_volume")

    @task_group(group_id="transformations")
    def transformations(rows):
        @task
        def transform_categories(rows: list[dict]) -> dict:
            return aggregate_by_category(rows)
        return transform_categories(rows)

    @task(pool="dwh_pool")
    def load(totals: dict, **context) -> dict:
        """Chargement IDEMPOTENT : DELETE de la journee puis INSERT."""
        ds = context["ds"]
        hook = PostgresHook(postgres_conn_id=CONN_ID)
        conn = hook.get_conn()
        with conn.cursor() as cur:
            cur.execute("DELETE FROM mart_daily_sales WHERE sale_date = %s", (ds,))
            cur.executemany(
                "INSERT INTO mart_daily_sales (sale_date, category, total_amount) VALUES (%s,%s,%s)",
                [(ds, category, total) for category, total in totals.items()],
            )
        conn.commit()
        print(f"{len(totals)} categories chargees pour {ds}")
        return totals

    @task(outlets=[sales_mart], trigger_rule="none_failed_min_one_success")
    def publish(totals: dict) -> None:
        print(f"Asset sales_mart mis a jour ({len(totals)} categories)")

    @task(trigger_rule="all_done")
    def notify() -> None:
        """Part TOUJOURS : succes comme echec. C'est le role d'une notification."""
        print("Run termine (succes ou echec) — notification envoyee")

    # POURQUOI cette tache "end" ?
    # L'etat d'un DAG run est determine par ses taches TERMINALES (les feuilles).
    # Si "notify" (trigger_rule=all_done) etait la seule feuille, elle reussirait
    # meme apres un echec en amont... et le run entier serait marque SUCCES.
    # Un pipeline qui masque ses propres echecs est inexploitable en production.
    #
    # "end" utilise la regle par defaut (all_success) : elle passe en upstream_failed
    # des qu'une tache amont echoue, ce qui fait echouer le run — comme il se doit.
    # On notifie TOUJOURS (notify), et on propage l'echec (end).
    end = EmptyOperator(task_id="end", trigger_rule="none_failed_min_one_success")

    rows = extract()
    wait_for_file >> create_tables >> rows
    branch = validate(rows)
    totals = transformations(rows)
    branch >> [totals, abort]
    published = publish(load(totals))
    [published, abort] >> notify()
    [published, abort] >> end


@dag(
    dag_id="snowystore_reporting_final",
    start_date=datetime(2026, 7, 20),
    schedule=[sales_mart],                   # declenche par la DONNEE
    catchup=False,
    tags=["snowystore", "tp12", "final"],
)
def snowystore_reporting_final():

    @task
    def build_report():
        hook = PostgresHook(postgres_conn_id=CONN_ID)
        records = hook.get_records(
            "SELECT sale_date, category, total_amount FROM mart_daily_sales "
            "ORDER BY sale_date DESC, total_amount DESC LIMIT 20"
        )
        for row in records:
            print("  ", row)

    build_report()


snowystore_final()
snowystore_reporting_final()

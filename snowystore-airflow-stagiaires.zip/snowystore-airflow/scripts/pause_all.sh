#!/usr/bin/env bash
# Met TOUS les DAGs en pause (ou les reactive avec --unpause).
#
# Pourquoi : l'etat active/en pause d'un DAG vit dans la BASE DE METADONNEES,
# pas dans le code. Un DAG active reste active apres 'astro dev stop', et au
# redemarrage le scheduler lance aussitot le dernier intervalle clos.
#
# Usage :
#   ./scripts/pause_all.sh              # tout mettre en pause
#   ./scripts/pause_all.sh --unpause    # tout reactiver
#   ./scripts/pause_all.sh --list       # voir l'etat actuel
set -u
cd "$(dirname "$0")/.."

ACTION="pause"
case "${1:-}" in
  --unpause) ACTION="unpause" ;;
  --list)    ACTION="list" ;;
  "")        ;;
  *) echo "Usage : $0 [--unpause|--list]"; exit 1 ;;
esac

if [ "$ACTION" = "list" ]; then
  astro dev bash -c "airflow dags list" 2>/dev/null | grep -v "^\[" || \
    echo "Impossible de lister — l'environnement est-il demarre ?"
  exit 0
fi

echo "=== ${ACTION} de tous les DAGs ==="
astro dev bash -c '
  DAGS=$(airflow dags list --output plain 2>/dev/null | awk "NR>1 {print \$1}" | grep -v "^$")
  if [ -z "$DAGS" ]; then echo "Aucun DAG trouve."; exit 0; fi
  for d in $DAGS; do
    airflow dags '"$ACTION"' "$d" >/dev/null 2>&1 && echo "  '"$ACTION"' : $d"
  done
'
echo
echo "Astuce : faites-le AVANT 'astro dev stop' pour que rien ne se declenche"
echo "au prochain demarrage."

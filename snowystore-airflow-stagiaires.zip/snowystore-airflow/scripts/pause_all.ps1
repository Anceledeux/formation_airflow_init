<#
.SYNOPSIS
    Met TOUS les DAGs en pause (equivalent de pause_all.sh).
.DESCRIPTION
    L'etat active/en pause d'un DAG vit dans la BASE DE METADONNEES, pas dans le code.
    Un DAG active le reste apres 'astro dev stop' : au redemarrage, le scheduler lance
    aussitot le dernier intervalle clos.
.EXAMPLE
    .\scripts\pause_all.ps1
    .\scripts\pause_all.ps1 -Unpause
    .\scripts\pause_all.ps1 -List
#>
param([switch]$Unpause, [switch]$List)

$ErrorActionPreference = "Continue"
Set-Location (Join-Path $PSScriptRoot "..")

if ($List) { astro dev bash -c "airflow dags list"; exit 0 }

$action = if ($Unpause) { "unpause" } else { "pause" }
Write-Host "=== $action de tous les DAGs ===" -ForegroundColor Cyan

$cmd = 'DAGS=$(airflow dags list --output plain 2>/dev/null | awk "NR>1 {print \$1}" | grep -v "^$"); ' +
       'if [ -z "$DAGS" ]; then echo "Aucun DAG trouve."; exit 0; fi; ' +
       'for d in $DAGS; do airflow dags ' + $action + ' "$d" >/dev/null 2>&1 && echo "  ' + $action + ' : $d"; done'

astro dev bash -c $cmd

Write-Host "`nAstuce : faites-le AVANT 'astro dev stop' pour que rien ne se declenche au prochain demarrage." -ForegroundColor Cyan

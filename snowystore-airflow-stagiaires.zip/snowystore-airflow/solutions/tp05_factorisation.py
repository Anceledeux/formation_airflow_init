"""TP5 — Factorisation dans include/ + gestion des erreurs (retries, callbacks).

La logique metier vit dans include/transform_logic.py :
  - le DAG devient lisible
  - la logique est testable sans Airflow (cf. tests/test_transform_logic.py)
"""
from __future__ import annotations

import csv
from datetime import datetime, timedelta
from pathlib import Path

from airflow.sdk import dag, task

from include.transform_logic import aggregate_by_category, clean_orders

DATA_DIR = Path("/usr/local/airflow/include/data")


def alert_on_failure(context):
    """on_failure_callback : formate une alerte actionnable.

    En production, on enverrait ce message sur Slack / PagerDuty via un notifier.
    """
    ti = context["task_instance"]
    print(
        "ALERTE ECHEC | dag=%s | task=%s | run=%s | try=%s"
        % (ti.dag_id, ti.task_id, context["run_id"], ti.try_number)
    )


@dag(
    dag_id="snowystore_factorise",
    start_date=datetime(2026, 7, 20),
    schedule="@daily",
    catchup=False,
    default_args={
        "owner": "formation",
        "retries": 2,
        "retry_delay": timedelta(seconds=30),
        "retry_exponential_backoff": True,      # 30s, 1min, 2min...
        "on_failure_callback": alert_on_failure,
    },
    tags=["snowystore", "tp5"],
)
def snowystore_factorise():

    @task
    def extract(**context) -> list[dict]:
        path = DATA_DIR / f"orders_{context['ds']}.csv"
        if not path.exists():
            raise FileNotFoundError(f"{path} introuvable")
        with path.open(encoding="utf-8") as fh:
            return list(csv.DictReader(fh))

    @task
    def transform(rows: list[dict]) -> dict[str, float]:
        """Le DAG orchestre, include/ fait le travail."""
        cleaned = clean_orders(rows)
        totals = aggregate_by_category(cleaned)
        print(f"{len(cleaned)} lignes propres, {len(totals)} categories")
        return totals

    @task
    def load(totals: dict[str, float]) -> None:
        for category, total in sorted(totals.items()):
            print(f"  {category:15} {total:>12.2f}")

    load(transform(extract()))


snowystore_factorise()

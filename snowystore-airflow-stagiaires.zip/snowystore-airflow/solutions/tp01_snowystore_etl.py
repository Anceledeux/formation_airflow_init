"""TP1 — Premier DAG Snowystore (approche classique).

Objectif : poser le squelette E-T-L. Les etapes "font semblant", on les remplira ensuite.
"""
from __future__ import annotations

from datetime import datetime, timedelta

from airflow.sdk import DAG
from airflow.providers.standard.operators.bash import BashOperator
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.providers.standard.operators.python import PythonOperator

default_args = {
    "owner": "formation",
    "retries": 2,
    "retry_delay": timedelta(minutes=1),
}


def transform_callable(**context):
    """Logique de transformation (pour l'instant, un simple log)."""
    print("Transformation des commandes Snowystore en cours...")
    return "transform_ok"


with DAG(
    dag_id="snowystore_etl",
    description="Fil rouge Snowystore : squelette ETL",
    start_date=datetime(2026, 6, 1),
    schedule="@daily",
    catchup=False,
    default_args=default_args,
    tags=["snowystore", "tp1"],
) as dag:

    extract = BashOperator(
        task_id="extract",
        bash_command="echo 'Extraction des commandes du {{ ds }}'",
    )

    transform = PythonOperator(
        task_id="transform",
        python_callable=transform_callable,
    )

    load = EmptyOperator(task_id="load")

    extract >> transform >> load

"""TP3 — Assets : producteur / consommateur (data-aware scheduling).

Le DAG de reporting n'a AUCUN horaire : il se declenche quand l'asset est mis a jour.

ORDRE D'EXECUTION IMPORTANT
---------------------------
1. ACTIVER d'abord les DAGs CONSOMMATEURS (interrupteur dans l'UI)
2. Puis lancer le PRODUCTEUR

Pourquoi ? Deux raisons :
  - un DAG en pause n'est jamais declenche, meme par un Asset ;
  - Airflow ne prend en compte que les evenements d'Asset survenus APRES
    l'enregistrement du consommateur. Un producteur lance trop tot produit
    un evenement "passe" que le consommateur ignorera.

Symptome typique si l'ordre n'est pas respecte : le producteur passe au vert,
le consommateur ne bouge pas, et l'UI affiche "0 sur N assets mis a jour".

Pour le DAG en condition ET (bonus), il faut lancer LES DEUX producteurs.
"""
from __future__ import annotations

from datetime import datetime

from airflow.sdk import Asset, dag, task

# Un Asset represente une DONNEE (table, fichier), pas une tache.
snowystore_sales = Asset("snowystore://sales")
snowystore_customers = Asset("snowystore://customers")


@dag(
    dag_id="tp3_producer_sales",
    start_date=datetime(2026, 7, 20),
    schedule="@daily",
    catchup=False,
    tags=["snowystore", "tp3", "producer"],
)
def tp3_producer_sales():

    @task(outlets=[snowystore_sales])       # <- cette tache PRODUIT l'asset
    def load_sales():
        print("Chargement des ventes -> asset snowystore_sales mis a jour")

    load_sales()


@dag(
    dag_id="tp3_producer_customers",
    start_date=datetime(2026, 7, 20),
    schedule="@daily",
    catchup=False,
    tags=["snowystore", "tp3", "producer"],
)
def tp3_producer_customers():

    @task(outlets=[snowystore_customers])
    def load_customers():
        print("Chargement des clients -> asset snowystore_customers mis a jour")

    load_customers()


@dag(
    dag_id="tp3_consumer_reporting",
    start_date=datetime(2026, 7, 20),
    schedule=[snowystore_sales],            # <- declenche par la DONNEE, pas par l'heure
    catchup=False,
    tags=["snowystore", "tp3", "consumer"],
)
def tp3_consumer_reporting():

    @task
    def build_report():
        print("Reporting genere (declenche par la mise a jour de snowystore_sales)")

    build_report()


@dag(
    dag_id="tp3_consumer_reporting_et",     # DEFI BONUS : condition ET
    start_date=datetime(2026, 7, 20),
    schedule=(snowystore_sales & snowystore_customers),
    catchup=False,
    tags=["snowystore", "tp3", "bonus"],
)
def tp3_consumer_reporting_et():

    @task
    def build_full_report():
        print("Reporting complet : les DEUX assets ont ete mis a jour")

    build_full_report()


tp3_producer_sales()
tp3_producer_customers()
tp3_consumer_reporting()
tp3_consumer_reporting_et()

"""TP8 — Variables de configuration + pattern producer / consumer.

Un seul code, une configuration externalisee :
changer la Variable suffit a faire suivre les deux DAGs (portabilite dev/staging/prod).
"""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from airflow.sdk import Variable, dag, task

DEFAULT_CONFIG = {
    "env": "formation",
    "output_dir": "/usr/local/airflow/include/data/out",
    "min_amount": 0,
}


def get_config() -> dict:
    """Lit la Variable JSON 'snowystore_config' (avec valeur de repli)."""
    raw = Variable.get("snowystore_config", default=json.dumps(DEFAULT_CONFIG))
    return json.loads(raw) if isinstance(raw, str) else raw


@dag(
    dag_id="tp8_producer",
    start_date=datetime(2026, 7, 20),
    schedule="@daily",
    catchup=False,
    tags=["snowystore", "tp8"],
)
def tp8_producer():

    @task
    def write_output(**context) -> str:
        config = get_config()
        out_dir = Path(config["output_dir"])
        out_dir.mkdir(parents=True, exist_ok=True)
        target = out_dir / f"sales_{context['ds']}.json"
        target.write_text(json.dumps({"ds": context["ds"], "env": config["env"], "total": 12345.67}))
        print(f"[{config['env']}] ecrit -> {target}")
        return str(target)

    write_output()


@dag(
    dag_id="tp8_consumer",
    start_date=datetime(2026, 7, 20),
    schedule="@daily",
    catchup=False,
    tags=["snowystore", "tp8"],
)
def tp8_consumer():

    @task
    def read_output(**context) -> None:
        config = get_config()          # MEME config que le producteur
        target = Path(config["output_dir"]) / f"sales_{context['ds']}.json"
        if not target.exists():
            print(f"Rien a lire pour {context['ds']} ({target})")
            return
        print(f"[{config['env']}] lu <- {target} : {target.read_text()}")

    read_output()


tp8_producer()
tp8_consumer()

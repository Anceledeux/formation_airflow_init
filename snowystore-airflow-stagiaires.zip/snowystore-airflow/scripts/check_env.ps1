<#
.SYNOPSIS
    Verifie que le poste est pret pour la formation Apache Airflow.
    Equivalent PowerShell de check_env.sh — A EXECUTER 3 JOURS AVANT LA FORMATION.
.EXAMPLE
    .\scripts\check_env.ps1
#>
Set-Location (Join-Path $PSScriptRoot "..")
$fail = 0
function OK($m)   { Write-Host "[ OK ] $m" -ForegroundColor Green }
function KO($m)   { Write-Host "[FAIL] $m" -ForegroundColor Red;    $script:fail = 1 }
function WARN($m) { Write-Host "[WARN] $m" -ForegroundColor Yellow }

Write-Host "=== Verification de l'environnement - Formation Apache Airflow ===" -ForegroundColor Cyan

# 0. Racine du projet Astro
if ((Test-Path ".astro\config.yaml") -and (Test-Path "Dockerfile")) {
    OK "projet Astro detecte ($(Get-Location))"
} else {
    KO "ce dossier n'est PAS la racine du projet Astro"
    Write-Host "       -> doit contenir .astro et Dockerfile"
    Write-Host "       -> l'archive cree parfois un dossier imbrique : essayez 'cd snowystore-airflow'"
}

# 1. Moteur de conteneurs
$engine = $null
if (Get-Command podman -ErrorAction SilentlyContinue) {
    podman info *>$null
    if ($LASTEXITCODE -eq 0) { OK "podman fonctionnel : $(podman --version)"; $engine = "podman" }
    else { KO "podman installe mais ne repond pas -> podman machine start" }
} elseif (Get-Command docker -ErrorAction SilentlyContinue) {
    docker info *>$null
    if ($LASTEXITCODE -eq 0) { OK "docker fonctionnel : $(docker --version)"; $engine = "docker" }
    else { KO "docker installe mais le daemon ne repond pas (lancer Docker Desktop)" }
} else {
    KO "ni podman ni docker trouve - voir INSTALLATION.md"
}

# 1b. Une seule machine Podman active ?
if ($engine -eq "podman") {
    $running = (podman machine list 2>$null | Select-String "Currently running").Count
    if ($running -gt 1) {
        KO "$running machines Podman actives -> conflit de connexion"
        Write-Host "       -> n'en garder qu'une : podman machine stop <autre-machine>"
    } elseif ($running -eq 1) { OK "une seule machine Podman active" }
}

# 2. Astro CLI
if (Get-Command astro -ErrorAction SilentlyContinue) {
    OK "astro CLI : $((astro version) -join ' ')"
    $bin = (astro config get -g container.binary 2>$null | Select-Object -Last 1)
    if ($engine -and $bin -and ($bin.Trim() -ne $engine)) {
        WARN "astro pointe sur '$($bin.Trim())' mais vous utilisez '$engine' -> astro config set -g container.binary $engine"
    } elseif ($bin) { OK "astro configure sur '$($bin.Trim())'" }
} else {
    KO "astro CLI absent - winget install -e --id Astronomer.Astro"
}

# 3. Python
if (Get-Command python -ErrorAction SilentlyContinue) {
    $v = (python -c "import sys;print(f'{sys.version_info.major}.{sys.version_info.minor}')")
    if ([version]$v -ge [version]"3.12") { OK "python $v" } else { WARN "python $v (>= 3.12 recommande)" }
} else { WARN "python absent (necessaire seulement hors conteneur)" }

# 4. Ports
foreach ($port in 8080, 5432, 5433) {
    $busy = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue
    if ($busy) { WARN "port $port deja utilise - liberer avant 'astro dev start'" }
    else { OK "port $port libre" }
}

# 5. RAM
$ram = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB)
if ($ram -ge 15) { OK "RAM $ram Go" }
elseif ($ram -ge 7) { WARN "RAM $ram Go - suffisant mais juste (16 Go recommandes)" }
else { KO "RAM $ram Go - insuffisant" }

# 6. Acces au registre d'images
if ($engine) {
    Write-Host "... test de telechargement d'image (peut prendre 30 s)"
    & $engine pull hello-world *>$null
    if ($LASTEXITCODE -eq 0) { OK "acces au registre d'images" }
    else { KO "impossible de telecharger une image - proxy/firewall ? Voir INSTALLATION.md" }
}

Write-Host "================================================================" -ForegroundColor Cyan
if ($fail -eq 0) { Write-Host "Poste PRET. A bientot en formation !" -ForegroundColor Green }
else { Write-Host "Des points bloquants subsistent : les signaler AVANT la formation." -ForegroundColor Red }
exit $fail

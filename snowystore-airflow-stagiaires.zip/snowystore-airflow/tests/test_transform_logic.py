"""TP6 — Tests unitaires de la logique metier.

Tout l'interet de la factorisation du TP5 : ces tests tournent en une fraction
de seconde, SANS demarrer Airflow, sans scheduler, sans base de donnees.
"""
from __future__ import annotations

import pytest

from include.transform_logic import aggregate_by_category, clean_orders, validate_totals


class TestCleanOrders:
    def test_normalise_les_categories(self):
        rows = [{"category": "  SKI ", "amount": "10.5"}]
        assert clean_orders(rows)[0]["category"] == "ski"

    def test_rejette_les_montants_negatifs(self):
        rows = [{"category": "ski", "amount": "-5"}]
        assert clean_orders(rows) == []

    def test_rejette_les_montants_non_numeriques(self):
        rows = [{"category": "ski", "amount": "abc"}]
        assert clean_orders(rows) == []

    def test_rejette_les_categories_vides(self):
        rows = [{"category": "  ", "amount": "10"}]
        assert clean_orders(rows) == []

    def test_conserve_les_lignes_valides(self):
        rows = [{"category": "ski", "amount": "10"}, {"category": "textile", "amount": "20"}]
        assert len(clean_orders(rows)) == 2

    def test_fichier_vide(self):
        assert clean_orders([]) == []


class TestAggregateByCategory:
    def test_somme_par_categorie(self):
        rows = [{"category": "ski", "amount": 10}, {"category": "ski", "amount": 5},
                {"category": "textile", "amount": 20}]
        assert aggregate_by_category(rows) == {"ski": 15.0, "textile": 20.0}

    def test_arrondi_a_deux_decimales(self):
        rows = [{"category": "ski", "amount": 10.005}, {"category": "ski", "amount": 0.001}]
        assert aggregate_by_category(rows)["ski"] == pytest.approx(10.01, abs=0.01)


class TestValidateTotals:
    def test_aucune_anomalie(self):
        assert validate_totals({"ski": 100.0}) == []

    def test_detecte_un_total_negatif(self):
        assert len(validate_totals({"ski": -1.0})) == 1

    def test_detecte_l_absence_de_donnees(self):
        assert len(validate_totals({})) == 1

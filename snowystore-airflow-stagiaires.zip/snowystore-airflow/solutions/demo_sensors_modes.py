"""DEMO — les trois modes d'attente d'un sensor, cote a cote.

A projeter au moment de la slide "Attendre un evenement : les Sensors" (Jour 2).
Ce n'est PAS un TP : c'est une demonstration de 3 minutes.

OBJECTIF : rendre visible ce que la slide decrit en mots. Les trois sensors
attendent le MEME fichier, mais dans trois modes differents. L'etat affiche
dans l'interface differe pour chacun -- c'est la toute la demonstration.

MODE D'EMPLOI (formateur)
-------------------------
1. S'assurer que le fichier attendu N'EXISTE PAS :
       rm -f include/data/demo_sensors.txt
2. Activer le DAG, puis le declencher manuellement.
3. Ouvrir la vue Grid et commenter les TROIS etats obtenus (voir plus bas).
4. Creer le fichier pour debloquer tout le monde :
       touch include/data/demo_sensors.txt
   Les trois sensors se debloquent a leur prochaine verification (~15 s).

CE QUE L'ON OBSERVE
-------------------
  poke        -> etat "running"           : la tache OCCUPE un slot d'execution
                                            pendant TOUTE l'attente
  reschedule  -> etat "up_for_reschedule" : la tache LIBERE son slot entre
                                            deux verifications
  deferrable  -> etat "deferred"          : ZERO slot, l'attente est portee
                                            par le Triggerer

Le message a faire passer : les trois attendent la meme chose et aboutissent au
meme resultat, mais leur COUT pour la plateforme n'a rien a voir. Avec cent
sensors en poke, l'instance est saturee ; en deferrable, elle ne l'est pas.
"""
from __future__ import annotations

from datetime import datetime

from airflow.sdk import dag, task
from airflow.providers.standard.sensors.filesystem import FileSensor

FICHIER = "/usr/local/airflow/include/data/demo_sensors.txt"


@dag(
    dag_id="demo_sensors_modes",
    start_date=datetime(2026, 1, 1),
    schedule=None,              # demonstration : declenchement manuel uniquement
    catchup=False,
    tags=["demo", "sensors"],
    doc_md=__doc__,             # la doc s'affiche dans l'onglet "Docs" du DAG
)
def demo_sensors_modes():

    # 1. POKE (mode par defaut) -- occupe un slot pendant toute l'attente.
    #    Etat affiche : "running"
    poke = FileSensor(
        task_id="mode_poke",
        filepath=FICHIER,
        mode="poke",
        poke_interval=15,
        timeout=60 * 5,
    )

    # 2. RESCHEDULE -- libere le slot entre deux verifications.
    #    Etat affiche : "up_for_reschedule"
    reschedule = FileSensor(
        task_id="mode_reschedule",
        filepath=FICHIER,
        mode="reschedule",
        poke_interval=15,
        timeout=60 * 5,
    )

    # 3. DEFERRABLE -- zero slot, l'attente est portee par le Triggerer.
    #    Etat affiche : "deferred"
    deferrable = FileSensor(
        task_id="mode_deferrable",
        filepath=FICHIER,
        deferrable=True,
        poke_interval=15,
        timeout=60 * 5,
    )

    @task(trigger_rule="all_done")
    def bilan():
        print("Les trois sensors ont attendu le MEME fichier.")
        print("Seul leur cout pour la plateforme differait.")

    [poke, reschedule, deferrable] >> bilan()


demo_sensors_modes()

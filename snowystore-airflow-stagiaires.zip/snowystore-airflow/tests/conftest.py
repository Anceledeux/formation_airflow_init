"""Rend les modules du projet importables depuis les tests (include/, dags/)."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
for path in (ROOT, ROOT / "dags"):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

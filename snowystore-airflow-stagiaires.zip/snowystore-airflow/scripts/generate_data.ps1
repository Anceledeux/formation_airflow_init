<#
.SYNOPSIS
    Genere les CSV de commandes du fil rouge (equivalent de generate_data.sh).
.EXAMPLE
    .\scripts\generate_data.ps1
    .\scripts\generate_data.ps1 -Days 30
#>
param([int]$Days = 20)

$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")

python include/generate_orders.py --days $Days
Write-Host ""
Write-Host "Astuce : pour le TP qualite de donnees, ajouter --anomalies" -ForegroundColor Cyan

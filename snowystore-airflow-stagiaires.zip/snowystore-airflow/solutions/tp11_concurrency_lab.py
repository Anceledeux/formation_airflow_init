"""TP11 (refondu) — Laboratoire de concurrence et de scalabilite.

Pourquoi ce TP a change : lancer un second docker-compose (Celery) a cote d'Astro
provoque des conflits de ports et sature les machines a 8 Go. On obtient le MEME
apprentissage — mesurer l'effet du parallelisme — sans la fragilite.

Protocole :
  1. Lancer avec pool_slots par defaut, noter la duree totale (vue Gantt)
  2. Rejouer en limitant : max_active_tasks=2 sur le DAG -> comparer
  3. Rejouer en rattachant les taches a dwh_pool (2 slots) -> comparer
Conclusion : la scalabilite se pilote par la concurrence, pas par le code des taches.
"""
from __future__ import annotations

import time
from datetime import datetime

from airflow.sdk import dag, task

N_TASKS = 12


@dag(
    dag_id="tp11_concurrency_lab",
    start_date=datetime(2026, 7, 20),
    schedule=None,                 # declenchement manuel : c'est un labo
    catchup=False,
    # ETAPE 2 : decommenter pour brider le DAG a 2 taches simultanees
    # max_active_tasks=2,
    tags=["snowystore", "tp11"],
)
def tp11_concurrency_lab():

    @task
    def make_batches() -> list[int]:
        return list(range(N_TASKS))

    @task                          # ETAPE 3 : ajouter pool="dwh_pool" ici
    def process_batch(batch_id: int) -> int:
        """Simule un traitement de 10 secondes."""
        time.sleep(10)
        print(f"Lot {batch_id} traite")
        return batch_id

    @task
    def summarize(results: list[int]) -> None:
        print(f"{len(results)} lots traites")

    summarize(process_batch.expand(batch_id=make_batches()))


tp11_concurrency_lab()

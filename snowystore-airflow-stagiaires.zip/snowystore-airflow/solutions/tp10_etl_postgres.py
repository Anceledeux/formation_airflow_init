"""TP10 — ETL reel vers PostgreSQL, idempotent, avec pool et Asset.

Points cles :
  - PostgresHook pour le Python, SQLExecuteQueryOperator pour le SQL
  - IDEMPOTENCE : DELETE de la journee AVANT INSERT -> rejouer ne cree pas de doublon
  - pool="dwh_pool" : au plus 2 ecritures concurrentes vers le DWH
  - la tache finale produit l'Asset sales_mart (chainage data-aware)
"""
from __future__ import annotations

import csv
from datetime import datetime
from pathlib import Path

from airflow.sdk import Asset, dag, task
from airflow.providers.common.sql.operators.sql import SQLExecuteQueryOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook

from include.transform_logic import aggregate_by_category, clean_orders, validate_totals

DATA_DIR = Path("/usr/local/airflow/include/data")
CONN_ID = "snowystore_dwh"
sales_mart = Asset("snowystore://sales_mart")


@dag(
    dag_id="snowystore_etl_postgres",
    start_date=datetime(2026, 7, 20),
    schedule="@daily",
    catchup=False,
    default_args={"owner": "formation", "retries": 2},
    tags=["snowystore", "tp10"],
)
def snowystore_etl_postgres():

    create_tables = SQLExecuteQueryOperator(
        task_id="create_tables",
        conn_id=CONN_ID,
        sql="""
        CREATE TABLE IF NOT EXISTS staging_orders (
            order_id    TEXT,
            customer_id TEXT,
            product_id  TEXT,
            category    TEXT,
            amount      NUMERIC(12,2),
            order_ts    TIMESTAMP,
            load_date   DATE
        );
        CREATE TABLE IF NOT EXISTS mart_daily_sales (
            sale_date   DATE,
            category    TEXT,
            total_amount NUMERIC(14,2),
            PRIMARY KEY (sale_date, category)
        );
        """,
    )

    @task(pool="dwh_pool")            # <- concurrence maitrisee sur le DWH
    def extract_to_staging(**context) -> int:
        """Charge le CSV du jour dans staging_orders (idempotent : DELETE puis INSERT)."""
        ds = context["ds"]
        path = DATA_DIR / f"orders_{ds}.csv"
        if not path.exists():
            raise FileNotFoundError(
                f"{path} introuvable — lancer : python include/generate_orders.py"
            )
        with path.open(encoding="utf-8") as fh:
            rows = clean_orders(list(csv.DictReader(fh)))

        hook = PostgresHook(postgres_conn_id=CONN_ID)
        conn = hook.get_conn()
        with conn.cursor() as cur:
            # IDEMPOTENCE : on efface la journee avant de la reinserer
            cur.execute("DELETE FROM staging_orders WHERE load_date = %s", (ds,))
            cur.executemany(
                "INSERT INTO staging_orders "
                "(order_id, customer_id, product_id, category, amount, order_ts, load_date) "
                "VALUES (%s, %s, %s, %s, %s, %s, %s)",
                [(r["order_id"], r["customer_id"], r["product_id"], r["category"],
                  r["amount"], r["order_ts"], ds) for r in rows],
            )
        conn.commit()
        print(f"{len(rows)} lignes chargees dans staging_orders pour {ds}")
        return len(rows)

    # Transformation idempotente en SQL : DELETE puis INSERT ... SELECT
    transform_to_mart = SQLExecuteQueryOperator(
        task_id="transform_to_mart",
        conn_id=CONN_ID,
        pool="dwh_pool",
        sql="""
        DELETE FROM mart_daily_sales WHERE sale_date = '{{ ds }}';
        INSERT INTO mart_daily_sales (sale_date, category, total_amount)
        SELECT load_date, category, SUM(amount)
        FROM staging_orders
        WHERE load_date = '{{ ds }}'
        GROUP BY load_date, category;
        """,
    )

    @task
    def data_quality_check(**context) -> dict:
        """DEFI BONUS : rejette le run si une anomalie est detectee."""
        hook = PostgresHook(postgres_conn_id=CONN_ID)
        records = hook.get_records(
            "SELECT category, total_amount FROM mart_daily_sales WHERE sale_date = %s",
            parameters=(context["ds"],),
        )
        totals = {category: float(total) for category, total in records}
        problems = validate_totals(totals)
        if problems:
            raise ValueError("Controle qualite en echec : " + " ; ".join(problems))
        print(f"Controle qualite OK — {len(totals)} categories")
        return totals

    @task(outlets=[sales_mart])       # <- produit l'Asset : declenche le reporting
    def publish(totals: dict) -> None:
        for category, total in sorted(totals.items()):
            print(f"  {category:15} {total:>12.2f}")
        print("Asset sales_mart mis a jour")

    # Chaque tache ne doit etre instanciee QU'UNE FOIS : un second appel
    # creerait une tache supplementaire (data_quality_check__1).
    rows = extract_to_staging()
    quality = data_quality_check()

    create_tables >> rows >> transform_to_mart >> quality
    publish(quality)


snowystore_etl_postgres()

"""TP3 bis — Sensor et modes d'attente (poke / reschedule / deferrable).

A comparer avec l'approche Asset du TP3 :
  - Asset  : la donnee est produite DANS Airflow  -> natif, pas d'attente active
  - Sensor : la donnee vient de l'EXTERIEUR      -> on verifie la presence du fichier
"""
from __future__ import annotations

from datetime import datetime

from airflow.sdk import dag, task
from airflow.providers.standard.sensors.filesystem import FileSensor


@dag(
    dag_id="tp3bis_sensor",
    start_date=datetime(2026, 7, 20),
    schedule="@daily",
    catchup=False,
    tags=["snowystore", "tp3bis"],
)
def tp3bis_sensor():

    # mode="reschedule" : libere le slot d'execution entre deux verifications.
    # mode="poke" (defaut) : occupe un slot pendant TOUTE l'attente -> a eviter si l'attente est longue.
    # NB : le FileSensor passe par un FSHook, qui a besoin d'une connexion de type "fs"
    # nommee "fs_default". Elle n'existe PAS par defaut en Airflow 3 : elle est
    # provisionnee dans airflow_settings.yaml du projet.
    # Sans elle : AirflowNotFoundException: The conn_id `fs_default` isn't defined
    wait_for_file = FileSensor(
        task_id="wait_for_orders_file",
        filepath="/usr/local/airflow/include/data/orders_{{ ds }}.csv",
        mode="reschedule",
        poke_interval=15,
        timeout=60 * 10,
    )

    @task
    def process():
        print("Fichier detecte : traitement des commandes")

    wait_for_file >> process()


tp3bis_sensor()

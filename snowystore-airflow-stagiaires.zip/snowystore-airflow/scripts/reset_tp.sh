#!/usr/bin/env bash
# POINT DE REPRISE : recopie le corrige d'un TP dans dags/ pour repartir sur une base saine.
# Indispensable avec un fil rouge cumulatif : personne ne reste bloque 3 jours.
#
# Usage :  ./scripts/reset_tp.sh tp05        -> installe le corrige du TP5
#          ./scripts/reset_tp.sh --list      -> liste les points de reprise
set -e
cd "$(dirname "$0")/.."

if [ "${1:-}" = "--list" ] || [ -z "${1:-}" ]; then
  echo "Points de reprise disponibles :"
  for f in solutions/*.py; do
    base=$(basename "$f" .py)
    echo "  ${base%%_*}  ->  $base"
  done | sort -u
  echo
  echo "Usage : ./scripts/reset_tp.sh tp05"
  exit 0
fi

TP="$1"
FOUND=$(find solutions -name "${TP}*.py" | head -1)
if [ -z "$FOUND" ]; then
  echo "Aucun corrige pour '$TP'. Lancer : ./scripts/reset_tp.sh --list"
  exit 1
fi

mkdir -p dags/_backup
cp dags/*.py dags/_backup/ 2>/dev/null || true
cp "$FOUND" dags/
echo "Corrige installe : $FOUND -> dags/$(basename "$FOUND")"
echo "(Votre travail precedent a ete sauvegarde dans dags/_backup/)"
echo "Le DAG apparaitra dans l'UI sous 30 s."

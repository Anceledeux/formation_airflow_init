"""Logique metier factorisee (extraite des DAGs au TP5).

Regle d'or : le DAG *orchestre*, ces fonctions *font*.
Consequence directe : ces fonctions se testent sans demarrer Airflow (cf. tests/).
"""
from __future__ import annotations

from typing import Iterable


def clean_orders(rows: Iterable[dict]) -> list[dict]:
    """Nettoie les commandes brutes : montants valides, categories normalisees."""
    cleaned = []
    for row in rows:
        try:
            amount = float(row.get("amount", 0))
        except (TypeError, ValueError):
            continue
        if amount <= 0:
            continue
        category = str(row.get("category", "")).strip().lower()
        if not category:
            continue
        cleaned.append({**row, "amount": amount, "category": category})
    return cleaned


def aggregate_by_category(rows: Iterable[dict]) -> dict[str, float]:
    """Agrege le chiffre d'affaires par categorie."""
    totals: dict[str, float] = {}
    for row in rows:
        category = str(row.get("category", "")).strip().lower()
        if not category:
            continue
        totals[category] = round(totals.get(category, 0.0) + float(row.get("amount", 0)), 2)
    return totals


def validate_totals(totals: dict[str, float]) -> list[str]:
    """Controle qualite : renvoie la liste des anomalies detectees (vide si tout va bien)."""
    problems = []
    for category, total in totals.items():
        if total < 0:
            problems.append(f"total negatif pour la categorie '{category}' : {total}")
    if not totals:
        problems.append("aucune donnee agregee")
    return problems

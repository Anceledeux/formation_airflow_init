"""TP6 — Sanity check : LE test le plus rentable de tout Airflow.

Verifie que tous les DAGs :
  - s'importent sans erreur
  - n'ont pas de cycle
  - ont un dag_id unique et au moins un tag

A lancer en CI sur chaque commit : plus aucun DAG casse n'atteint la production.
"""
from __future__ import annotations

import pytest
from airflow.models import DagBag


@pytest.fixture(scope="session")
def dagbag() -> DagBag:
    return DagBag(dag_folder="dags/", include_examples=False)


def test_no_import_errors(dagbag: DagBag):
    """Aucun DAG ne doit lever d'erreur a l'import."""
    assert not dagbag.import_errors, f"Erreurs d'import : {dagbag.import_errors}"


def test_dags_are_loaded(dagbag: DagBag):
    assert dagbag.dags, "Aucun DAG trouve dans dags/"


def test_every_dag_has_tags(dagbag: DagBag):
    """Convention d'equipe : un DAG sans tag est introuvable dans une UI qui en affiche 100."""
    untagged = [dag_id for dag_id, dag in dagbag.dags.items() if not dag.tags]
    assert not untagged, f"DAGs sans tag : {untagged}"


def test_every_dag_has_owner(dagbag: DagBag):
    missing = [dag_id for dag_id, dag in dagbag.dags.items()
               if not dag.default_args.get("owner") and dag.owner in (None, "", "airflow")]
    assert not missing, f"DAGs sans owner explicite : {missing}"
